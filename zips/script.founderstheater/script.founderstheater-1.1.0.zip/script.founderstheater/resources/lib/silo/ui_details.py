"""The details screen, styled after the Silo Android TV app.

A hero (backdrop, title or logo, facts, synopsis) sits above a row of
actions. Series add season capsules and an episode rail; every title can
show its cast, trailers and extras, a movie's box set, related titles and a
facts table further down. BoxSetWindow reuses the layout for one box set. Round Watchlist and Favorite toggles and a More menu (shuffle,
mark watched, go to series or season, media info, translation) follow the
play actions. The page scrolls in zones:
Python moves focus up and down between zones and slides the page so the
focused zone is in view, while left and right stay native inside a zone.
The layout constants here match scripts/skin_details.py.
"""

import re
from urllib.parse import quote, urlsplit

import xbmc
import xbmcgui

from . import present, svc_boxsets, svc_browse, svc_party, svc_personal, svc_shuffle
from .api import ApiError
from .present import is_unwatched, language_name
from .media import (available_versions, default_version, format_time, is_multipart, resume_position,
                    subtitle_choices, version_label, version_name)
from .player_extras import audio_track_label
from .ui_common import (ACTION_DOWN, ACTION_LEFT, ACTION_RIGHT, ACTION_UP, BACK_ACTIONS, CONTEXT_ACTIONS, Debouncer,
                        card_list_item, card_menu, collection_list_item, set_properties)

PLAY, RESUME, VERSION, START_OVER, NEXT_UP, SUBTITLES = 100, 101, 103, 104, 105, 106
WATCHLIST, FAVORITE, MORE, AUDIO = 107, 108, 109, 110
# Read more opens the full synopsis when it is longer than the three lines the hero shows.
READ_MORE, PLOT_PREVIEW = 112, 230
SEASONS, EPISODES, CAST, SIMILAR, BOXSET, EXTRAS, FACTS, COLLECTIONS = 510, 520, 530, 540, 550, 560, 570, 580
PAGE, CAST_GROUP, SIMILAR_GROUP, BOXSET_GROUP, EXTRAS_GROUP, FACTS_GROUP = 1000, 3000, 4000, 4500, 5000, 6000
COLLECTIONS_GROUP = 4600
SUPERTITLE, TITLE, TITLE2 = 1101, 1102, 1103
CHIP, CHIP_LABEL, BADGE, BADGE_LABEL, META = 1201, 1202, 1211, 1221, 1230
# A button's group id is 1300 + its id; the order is the on-screen order.
BUTTON_ORDER = (NEXT_UP, PLAY, RESUME, START_OVER, VERSION, AUDIO, SUBTITLES, WATCHLIST, FAVORITE, MORE)
CAPSULES = (NEXT_UP, PLAY)
# Android puts a movie's box set between the trailers and More Like This, and its collections
# row below the box set; a series has its collections row right below Cast & Crew.
ZONES = ("synopsis", "buttons", "seasons", "episodes", "cast", "extras", "boxset", "collections", "similar", "facts")
SERIES_ZONES = ("synopsis", "buttons", "seasons", "episodes", "cast", "collections", "extras", "boxset", "similar",
                "facts")
ZONE_CONTROLS = {"synopsis": READ_MORE, "seasons": SEASONS, "episodes": EPISODES, "cast": CAST, "extras": EXTRAS,
                 "boxset": BOXSET, "collections": COLLECTIONS, "similar": SIMILAR, "facts": FACTS}

LEFT = 100
TEXT_RIGHT = LEFT + 1080
TITLE_BOTTOM = 276
META_TOP = 294
BUTTON_TOP = 556
BUTTON_GAP = 18
CIRCLE = 76
MAX_BADGES = 5
# Where the cast section starts below the action row, or below the episode rail.
SECTIONS_TOP = 700
SECTIONS_TOP_SERIES = 1100
CAST_HEIGHT = 400
EXTRAS_HEIGHT = 400
SIMILAR_HEIGHT = 460
BOXSET_HEIGHT = 460
COLLECTIONS_HEIGHT = 460
MAX_FACTS = 12
# A scrolled-to section's heading sits this far from the top of the screen.
SECTION_SCROLL_TOP = 140
SEASON_SETTLE_SECONDS = 0.3
MAX_CAST = 30

YOUTUBE_ADDON = "plugin.video.youtube"
YOUTUBE_PLAY = "plugin://plugin.video.youtube/play/?video_id={}"
YOUTUBE_THUMB = "https://i.ytimg.com/vi/{}/hqdefault.jpg"
_YOUTUBE_KEY = re.compile(r"[A-Za-z0-9_-]{6,32}")
EXTRA_KINDS = {"trailer": "Trailer", "teaser": "Teaser", "featurette": "Featurette", "clip": "Clip",
               "behind_the_scenes": "Behind the Scenes", "deleted_scene": "Deleted Scene",
               "interview": "Interview", "short": "Short", "scene": "Scene", "bloopers": "Bloopers"}
MONTHS = ("January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
          "November", "December")
# Titles the profile can rate 1 to 5 stars from the More menu (svc_personal.set_rating).
# Silo stores a rating as 1 to 10, two per star; the menu offers whole stars.
RATED_KINDS = ("movie", "series")
BOX_SET_UNAVAILABLE = ("This box set isn't available. Box sets may be turned off for this library, "
                       "or too few of its movies are here.")


def _text(value):
    return str(value).strip() if value not in (None, "") else ""


def stars_label(score):
    """A 1 to 10 rating as stars ("3.5 stars"). Plain text: Kodi's default skin font may not draw a star character."""
    return "1 star" if score == 2 else "{:g} stars".format(score / 2)


def split_title(title):
    """Android puts a subtitle after ``:`` or a dash on its own, smaller line."""
    for separator in (": ", " — ", " – "):
        head, found, tail = title.partition(separator)
        if found and head.strip() and tail.strip():
            return head.strip(), tail.strip()
    return title, ""


def capsule_width(text):
    # The icon and its padding (74 px), the text at up to 16 px per character of
    # font25_title, then the pill's right padding. The text never scrolls, so err wide.
    return max(170, 74 + 16 * len(text) + 32)


def chip_width(text):
    return 24 + 13 * len(text)


# ------------------------------------------------------------- pure helpers


def long_date(value):
    """``2024-03-09`` -> ``March 9, 2024``; other text is returned as is."""
    value = _text(value)
    parts = value[:10].split("-")
    try:
        year, month, day = int(parts[0]), int(parts[1]), int(parts[2])
        return "{} {}, {}".format(MONTHS[month - 1], day, year)
    except (ValueError, IndexError):
        return value


def _names(values, limit=3):
    names = [_text(value) for value in values if _text(value)] if isinstance(values, list) else []
    return ", ".join(names[:limit])


def _crew(item, tokens):
    crew = item.get("crew") if isinstance(item.get("crew"), list) else []
    names = []
    for person in crew:
        if not isinstance(person, dict):
            continue
        job, name = _text(person.get("job")).lower(), _text(person.get("name"))
        if name and name not in names and any(token in job for token in tokens):
            names.append(name)
    return ", ".join(names[:3]) + (", …" if len(names) > 3 else "")


def ratings_line(item):
    """Every external rating the server shows, as "IMDb 8.5 · TMDB 7.9"."""
    ratings = item.get("ratings") if isinstance(item.get("ratings"), list) else []
    parts = ["{} {}".format(_text(rating.get("name")), _text(rating.get("display"))).strip()
             for rating in ratings if isinstance(rating, dict) and _text(rating.get("display"))]
    if parts:
        return " · ".join(parts)
    fallback = []
    for key, name in (("rating_imdb", "IMDb"), ("rating_tmdb", "TMDB")):
        if isinstance(item.get(key), (int, float)) and not isinstance(item.get(key), bool) and item[key]:
            fallback.append("{} {:.1f}".format(name, item[key]))
    for key, name in (("rating_rt_critic", "Rotten Tomatoes"), ("rating_rt_audience", "RT Audience")):
        if isinstance(item.get(key), int) and not isinstance(item.get(key), bool):
            fallback.append("{} {}%".format(name, item[key]))
    return " · ".join(fallback)


def facts(item, version=None):
    """The Details table: (label, value) rows in the Android facts order."""
    rows = [("Director", _crew(item, ("director",))),
            ("Written by", _crew(item, ("writer", "screenplay", "story", "teleplay"))),
            ("Created by", _crew(item, ("creator",))),
            ("Studio", _names(item.get("studios"))),
            ("Network", _names(item.get("networks"))),
            ("Country", _names(item.get("countries")))]
    title, original = _text(item.get("title")), _text(item.get("original_title"))
    rows.append(("Original title", original if original and original != title else ""))
    rows.append(("Original language", language_name(item.get("original_language"))))
    if version:
        audio = []
        for track in version.get("audio_tracks") or []:
            name = language_name(track.get("language")) if isinstance(track, dict) else ""
            if name and name not in audio:
                audio.append(name)
        rows.append(("Audio", ", ".join(audio)))
    rows.append(("Genres", _names(item.get("genres"), limit=10)))
    if item.get("type") == "episode":
        rows.append(("Aired", long_date(item.get("air_date") or item.get("release_date"))))
    else:
        rows += [("Released", long_date(item.get("release_date"))),
                 ("First aired", long_date(item.get("first_air_date"))),
                 ("Last aired", long_date(item.get("last_air_date")))]
    rows.append(("Ratings", ratings_line(item)))
    return [(label, value) for label, value in rows if value][:MAX_FACTS]


def _codec(value):
    value = _text(value)
    return {"hevc": "HEVC", "h265": "HEVC", "h264": "H.264", "avc": "H.264", "subrip": "SRT",
            "hdmv_pgs_subtitle": "PGS", "webvtt": "VTT", "dca": "DTS"}.get(value.lower(), value.upper())


def _channels(count):
    return {1: "Mono", 2: "Stereo", 6: "5.1", 8: "7.1"}.get(count, "{}ch".format(count)) if count else ""


def _size(value):
    if not isinstance(value, (int, float)) or value <= 0:
        return ""
    gigabytes = value / 1024.0 ** 3
    return "{:.2f} GB".format(gigabytes) if gigabytes >= 1 else "{:.0f} MB".format(value / 1024.0 ** 2)


def _join(*parts):
    return " · ".join(_text(part) for part in parts if _text(part))


def media_info_text(version):
    """Container, video, audio and subtitle tracks of one file version.

    The file name leads when Silo sends it. Silo keeps it from accounts that may not curate
    metadata; the text then starts with the container line, with no made-up name.
    """
    if not version:
        return "No media details are available."
    name = version_name(version)
    lines = [name] if name else []
    duration = version.get("duration")
    bitrate = version.get("bitrate")
    lines.append(_join(_text(version.get("container")).upper(), _text(version.get("resolution")),
                       _size(version.get("file_size")),
                       "{} kbps".format(bitrate) if isinstance(bitrate, int) and bitrate > 0 else "",
                       format_time(duration) if isinstance(duration, (int, float)) and duration > 0 else ""))
    video = [track for track in version.get("video_tracks") or [] if isinstance(track, dict)]
    lines += ["", "[B]Video[/B]"]
    if video:
        for track in video:
            size = "{}x{}".format(track["width"], track["height"]) if track.get("width") and track.get("height") else ""
            dynamic = _text(track.get("video_range_type") or track.get("video_range"))
            if track.get("dolby_vision") or track.get("dv_profile"):
                dynamic = _join(dynamic, "Dolby Vision" + (" P{}".format(track["dv_profile"])
                                                           if track.get("dv_profile") else ""))
            lines.append("• " + _join(_codec(track.get("codec")), size, dynamic,
                                      "{} fps".format(track["frame_rate"]) if track.get("frame_rate") else "",
                                      "{}-bit".format(track["bit_depth"]) if track.get("bit_depth") else ""))
    else:
        lines.append("• " + _join(_codec(version.get("codec_video")), version.get("resolution"),
                                  "HDR" if version.get("hdr") else ""))
    audio = [track for track in version.get("audio_tracks") or [] if isinstance(track, dict)]
    lines += ["", "[B]Audio[/B]"]
    if audio:
        for track in audio:
            lines.append("• " + _join(language_name(track.get("language")), track.get("title"),
                                      _codec(track.get("codec")), _channels(track.get("channels")),
                                      "Default" if track.get("default") else ""))
    else:
        lines.append("• " + (_codec(version.get("codec_audio")) or "Unknown"))
    subtitles = [track for track in version.get("subtitle_tracks") or [] if isinstance(track, dict)]
    if subtitles:
        lines += ["", "[B]Subtitles[/B]"]
        for track in subtitles:
            lines.append("• " + _join(language_name(track.get("language")) or "Unknown", track.get("title"),
                                      _codec(track.get("codec")), "Forced" if track.get("forced") else "",
                                      "SDH" if track.get("hearing_impaired") else "",
                                      "External" if track.get("external") else ""))
    return "\n".join(line for line in lines if line is not None)


def extra_kind_label(kind):
    kind = _text(kind).lower().replace("-", "_")
    return EXTRA_KINDS.get(kind) or (" ".join(word.capitalize() for word in kind.split("_") if word) or "Extra")


def duration_label(seconds):
    if not isinstance(seconds, (int, float)) or isinstance(seconds, bool) or seconds <= 0:
        return ""
    return format_time(seconds)


def trailer_entries(item, youtube_available):
    """Local extras first (they play in Silo), then YouTube videos when they can play."""
    entries, seen = [], set()
    for extra in item.get("extras") or []:
        if not isinstance(extra, dict) or not _text(extra.get("content_id")):
            continue
        key = "local:" + _text(extra["content_id"])
        if key in seen:
            continue
        seen.add(key)
        kind = extra_kind_label(extra.get("kind"))
        entries.append({"source": "local", "extra": extra, "title": _text(extra.get("title")) or kind,
                        "label2": _join(kind, duration_label(extra.get("duration_seconds"))),
                        "still": _text(extra.get("still_url"))})
    if youtube_available:
        for video in item.get("videos") or []:
            if not isinstance(video, dict) or _text(video.get("site")).lower() != "youtube":
                continue
            key = _text(video.get("site_key"))
            if not _YOUTUBE_KEY.fullmatch(key) or "remote:" + key in seen:
                continue
            seen.add("remote:" + key)
            kind = extra_kind_label(video.get("kind"))
            entries.append({"source": "youtube", "key": key, "title": _text(video.get("name")) or kind,
                            "label2": _join(kind, "YouTube"), "thumb": YOUTUBE_THUMB.format(key)})
    return entries


class DetailsWindow(xbmcgui.WindowXML):
    """A title's metadata and actions, with season/episode navigation."""

    def __init__(self, *args, **kwargs):
        self.application = None
        self.item = {}
        # On a series or season page, the next-up episode's own detail: Play, Start over and
        # the Version, Audio and Subtitles choosers act on it (see target()).
        self.next_up = None
        self.children = []
        self.initialized = False
        self.selected_file_id = None
        self.file_confirmed = False
        # Playback ordinal of the chosen subtitle; None plays without subtitles.
        # It starts from the remembered choice or the profile's preferences.
        self.subtitle_index = None
        self.subtitle_source = "auto"
        # Audio ordinal: what playback would choose, until Audio picks another.
        self.audio_index = None
        self.audio_source = "auto"
        self.audio_label = ""
        self.can_resume = False
        self.show_plot = True
        self.hide_spoilers = False
        self.resume_label = ""
        self.subtitle_label = ""
        self.play_label = "Play"
        self.continue_label = "Play"
        self.seasons = []
        self.season_index = 0
        self.episodes = []
        self.episode_cache = {}
        # The rail's selection after the last move, to tell a press at its end from a move onto it.
        self.rail_position = None
        self.cast = []
        self.similar = []
        # The box set row: the box set, its movies in release order, and whether Explore all ends it.
        self.box_set = None
        self.box_set_movies = []
        self.box_set_explore = False
        # The collections row: the collections holding the title and, when only one does,
        # its other titles shown in place of its card (then Explore all opens it).
        self.collection_cards = []
        self.collection_preview = []
        self.extras = []
        self.facts = []
        self.visible_buttons = []
        self.focusable_buttons = []
        self.last_button = None
        self.focus_id = None
        self.hero_episode = None
        self.hero_overview = ""
        self.scroll_offset = 0
        self.cast_top = SECTIONS_TOP
        self.similar_top = SECTIONS_TOP
        self.boxset_top = SECTIONS_TOP
        self.collections_top = SECTIONS_TOP
        self.extras_top = SECTIONS_TOP
        self.facts_top = SECTIONS_TOP
        # Server capabilities, read once per page when the More menu needs them.
        self.shuffle_kinds = None
        self.metadata_ai = None
        self.party_support = None
        self.season_settle = Debouncer(self.season_settled, SEASON_SETTLE_SECONDS)

    # ------------------------------------------------------------ lifecycle
    def onInit(self):
        if self.initialized:
            return
        self.initialized = True
        options = self.application.options()
        self.show_plot = options["show_plot"]
        self.hide_spoilers = bool(options.get("hide_spoilers"))
        self.load_next_up()
        self.update_file_selection()
        self.default_subtitle()
        self.update_subtitle_selection()
        self.default_audio()
        self.update_audio_selection()
        self.load_children()
        self.load_cast()
        self.load_extras()
        self.load_facts()
        self.update_actions()
        self.show_hero()
        self.layout_sections()
        # Play applies the saved preference; Resume/Start are explicit alternatives.
        zones = self.available_zones()
        if PLAY in self.focusable_buttons:
            self.focus_control(PLAY)
        elif zones:
            # Read more sits above the buttons but is never where the page opens.
            self.focus_zone(next((zone for zone in zones if zone != "synopsis"), zones[0]))
        self.load_box_set()
        self.load_collections()
        self.load_similar()

    def onAction(self, action):
        action_id = action.getId()
        if action_id in BACK_ACTIONS:
            self.season_settle.cancel()
            self.close()
        elif action_id in CONTEXT_ACTIONS:
            self.application.guard(self.open_card_menu)
        elif action_id in (ACTION_UP, ACTION_DOWN):
            self.move_zone(-1 if action_id == ACTION_UP else 1)
        elif action_id in (ACTION_LEFT, ACTION_RIGHT):
            focused = self.focused()
            if focused == SEASONS:
                self.season_settle.trigger()
            elif focused == EPISODES and not self.cross_season(action_id):
                self.show_focused_episode()

    def onFocus(self, control_id):
        self.focus_id = control_id
        zone = self.zone_of(control_id)
        if zone == "buttons":
            self.last_button = control_id
        if zone == "episodes":
            self.show_focused_episode()
        elif self.hero_episode is not None:
            self.hero_episode = None
            self.show_hero()
        self.setProperty("silo.hint", self.hint(control_id))
        if zone:
            self.scroll_to(zone)

    def onClick(self, control_id):
        self.application.guard(lambda: self._click(control_id))

    def _click(self, control_id):
        if control_id == READ_MORE:
            title = _text(self.item.get("title") or self.item.get("name")) or "Synopsis"
            self.application.dialog.textviewer(title, self.hero_overview)
        elif control_id == VERSION:
            file_id = self.application.choose_file(self.target(), self.selected_file_id)
            if file_id is not None:
                self.refresh(file_id)
        elif control_id == AUDIO:
            self.choose_audio()
        elif control_id == SUBTITLES:
            choices = self.subtitle_options()
            chosen = self.application.choose_subtitle(choices, self.subtitle_index)
            if chosen is not False:
                self.subtitle_index, self.subtitle_source = chosen, "picked"
                target = self.target()
                version = default_version(target, preferred_file_id=self.selected_file_id)
                remember = getattr(self.application, "remember_subtitle", None)
                if callable(remember):
                    self.application.guard(lambda: remember(target, version, chosen))
                self.update_subtitle_selection()
                self.setProperty("silo.hint", self.hint(SUBTITLES))
        elif control_id == NEXT_UP and self.item.get("play_content_id"):
            if self.next_up:
                self.play_target(None)
            elif self.application.play_next(self.item) is not None:
                self.reload_episodes()
        elif control_id in (PLAY, RESUME, START_OVER):
            self.play_target({PLAY: None, RESUME: True, START_OVER: False}[control_id])
        elif control_id == SEASONS:
            self.season_settle.cancel()
            self.season_settled()
        elif control_id == EPISODES:
            episode = self.selected(EPISODES, self.episodes)
            if episode is not None:
                self.play_episode(episode)
        elif control_id == SIMILAR:
            item = self.selected(SIMILAR, self.similar)
            if item is not None:
                self.application.open_item(item)
        elif control_id == BOXSET:
            self.open_box_set_card()
        elif control_id == COLLECTIONS:
            self.open_collections_card()
        elif control_id in (WATCHLIST, FAVORITE):
            self.toggle_mark("watchlist" if control_id == WATCHLIST else "favorite")
        elif control_id == MORE:
            self.open_more()
        elif control_id == CAST:
            person = self.selected(CAST, self.cast)
            if person is not None and _text(person.get("person_id")):
                self.application.open_screen("person", person_id=_text(person["person_id"]),
                                             name=_text(person.get("name")))
        elif control_id == EXTRAS:
            entry = self.selected(EXTRAS, self.extras)
            if entry is not None:
                self.play_extra(entry)

    def selected(self, control_id, items):
        position = self.getControl(control_id).getSelectedPosition()
        return items[position] if 0 <= position < len(items) else None

    def play_target(self, resume):
        """Play what the page plays (see target()) as the page shows it: the version on screen
        (Version changes it), and a track picked with Audio; otherwise preferences decide."""
        audio = {"audio_index": self.audio_index} if self.audio_source == "picked" else {}
        file_id = self.application.play(self.target(), resume=resume, file_id=self.selected_file_id,
                                        subtitle_index=self.subtitle_index, **audio)
        if file_id is not None:
            self.refresh(file_id, after_playback=True)

    def open_card_menu(self):
        """Long-press on an episode card: mark it watched or a favorite, as Android's rail offers,
        or open the episode's own page (OK plays the episode instead)."""
        if self.focused() != EPISODES:
            return
        episode = self.selected(EPISODES, self.episodes)
        if episode is None:
            return
        key = card_menu(self.application, episode, ("watched", "favorite"), after=[("open", "Go to episode")])
        if key == "open":
            self.application.open_item(episode)
        elif key == "watched":
            # The series' progress and next-up episode follow, and the rail shows the new mark.
            self.refresh(self.selected_file_id)
            self.reload_children()

    def play_episode(self, episode):
        """OK on an episode card plays it at once (Android seriesEpisodePlaybackLaunch). The
        page's choices go with it only on the next-up episode they were made for; any other
        episode is read and played from its own defaults. Long-press opens its page."""
        if self.next_up and episode.get("content_id") == self.next_up.get("content_id"):
            self.play_target(None)
            return
        detail = self.application.client.item(episode["content_id"])
        if not isinstance(detail, dict) or not self.application.is_playable(detail):
            return
        file_id = self.application.play(detail, fresh=True)
        if file_id is not None:
            self.refresh(file_id, after_playback=True)

    # ------------------------------------------------------------- next up
    def plays_next_up(self):
        return self.item.get("type") in ("series", "season")

    def target(self):
        """What Play, Start over and the choosers act on: the page's own title, or on a series
        or season page its next-up episode ({} until that episode's detail is read)."""
        return (self.next_up or {}) if self.plays_next_up() else self.item

    def load_next_up(self):
        """Read a series or season page's next-up episode, so its versions, tracks and progress
        drive the buttons (Android nextUpPlaybackDetail). Without it, Next Up plays as before."""
        self.next_up = None
        content_id = self.item.get("play_content_id")
        if not self.plays_next_up() or not content_id:
            return
        try:
            episode = self.application.client.item(content_id)
        except Exception:  # Optional: Next Up still plays the episode without it.
            return
        if isinstance(episode, dict) and episode.get("content_id") == content_id \
                and self.application.is_playable(episode):
            self.next_up = episode

    def refresh_series(self, file_id, after_playback):
        """A series or season page reads itself again. After playback, or once another episode
        is next up, the choices start over from that episode's own defaults."""
        before = (self.next_up or {}).get("content_id")
        self.item = self.application.refresh_item(self.item)
        if after_playback or not self.next_up or self.item.get("play_content_id") != before:
            self.selected_file_id = None
            self.load_next_up()
            self.default_subtitle()
            self.default_audio()
        else:
            self.next_up = self.application.refresh_item(self.next_up, file_id)
            if file_id != self.selected_file_id:
                self.selected_file_id = file_id
                self.default_subtitle()
                self.default_audio()
        self.update_file_selection()
        self.update_subtitle_selection()
        self.update_audio_selection()
        self.update_actions()
        if self.hero_episode is None:
            self.show_hero()
        if after_playback:
            self.reload_children()

    # ------------------------------------------------------------- versions
    def update_file_selection(self):
        version = default_version(self.target(), self.application.options()["file_selection"], self.selected_file_id)
        self.selected_file_id = version["file_id"] if version else None
        self.setProperty("silo.has_file", "true" if version else "")
        if version:
            label, name = version_label(version), version_name(version)
            self.setProperty("silo.file_label", "File: " + label + (" — " + name if name and name != label else ""))
        else:
            self.setProperty("silo.file_label", "File: No media files available")

    def subtitle_options(self):
        version = default_version(self.target(), preferred_file_id=self.selected_file_id)
        return subtitle_choices(version)

    def default_subtitle(self):
        """Start from the remembered choice or the profile's subtitle preferences."""
        target = self.target()
        version = default_version(target, preferred_file_id=self.selected_file_id)
        try:
            index, source = self.application.subtitle_default(target, version)
        except (AttributeError, TypeError, ValueError):
            index, source = None, "auto"
        self.subtitle_index = index if isinstance(index, int) and not isinstance(index, bool) else None
        self.subtitle_source = source if source in ("auto", "remembered") else "auto"

    def update_subtitle_selection(self):
        choices = dict(self.subtitle_options())
        if self.subtitle_index not in choices:
            self.subtitle_index = None
        self.setProperty("silo.has_subtitles", "true" if choices else "")
        label = choices.get(self.subtitle_index, "Off")
        if self.subtitle_index is not None and self.subtitle_source == "auto":
            label += " (Auto)"  # Chosen from the profile's subtitle preferences.
        self.subtitle_label = "Subtitles: " + label
        self.setProperty("silo.subtitle_label", self.subtitle_label)

    def audio_options(self):
        """(ordinal, label) for each audio track of the version on screen."""
        version = default_version(self.target(), preferred_file_id=self.selected_file_id)
        tracks = (version or {}).get("audio_tracks") or []
        return [(index, audio_track_label(track, index)) for index, track in enumerate(tracks)]

    def default_audio(self):
        """Start from the track playback would choose: Silo's saved preference first."""
        target = self.target()
        version = default_version(target, preferred_file_id=self.selected_file_id)
        try:
            index, _language = self.application.audio_default(target, version)
        except (AttributeError, TypeError, ValueError):
            index = None
        self.audio_index = index if isinstance(index, int) and not isinstance(index, bool) else None
        self.audio_source = "auto"

    def update_audio_selection(self):
        choices = dict(self.audio_options())
        if self.audio_index not in choices:
            self.audio_index, self.audio_source = None, "auto"
        self.setProperty("silo.has_audio_choice", "true" if len(choices) > 1 else "")
        label = choices.get(self.audio_index, "Automatic")
        if self.audio_index is not None and self.audio_source == "auto":
            label += " (Auto)"  # What the profile's audio preferences will play.
        self.audio_label = "Audio: " + label

    def choose_audio(self):
        choices = self.audio_options()
        indexes = [index for index, _label in choices]
        current = indexes.index(self.audio_index) if self.audio_index in indexes else 0
        chosen = self.application.dialog.select("Audio", [label for _index, label in choices], preselect=current)
        if not isinstance(chosen, int) or not 0 <= chosen < len(choices):
            return
        self.audio_index, self.audio_source = indexes[chosen], "picked"
        target = self.target()
        version = default_version(target, preferred_file_id=self.selected_file_id)
        remember = getattr(self.application, "remember_audio", None)
        if callable(remember):
            self.application.guard(lambda: remember(target, version, indexes[chosen]))
        self.update_audio_selection()
        self.setProperty("silo.hint", self.hint(AUDIO))

    def update_resume(self):
        target = self.target()
        resume = self.application.resume_seconds(target) if target else 0
        playable = bool(target) and self.application.is_playable(target)
        version = default_version(target, preferred_file_id=self.selected_file_id)
        # A shared item offset is not a valid seek point inside a multipart file.
        self.can_resume = bool(playable and resume > 0 and not is_multipart(version))
        self.resume_label = "Resume from {}".format(format_time(resume))
        self.setProperty("silo.resume", "true" if self.can_resume else "")
        self.setProperty("silo.resume_label", self.resume_label)
        return resume

    def refresh(self, file_id, after_playback=False):
        if self.plays_next_up():
            self.refresh_series(file_id, after_playback)
            return
        item = (self.application.item_after_playback(self.item, file_id) if after_playback
                else self.application.refresh_item(self.item, file_id))
        changed_file = file_id != self.selected_file_id
        self.item = item
        self.selected_file_id = file_id
        if changed_file or after_playback:
            # Another version has its own tracks, and a pick made in the player
            # menu during playback is now the remembered choice.
            self.default_subtitle()
            self.default_audio()
        self.file_confirmed = any(version["file_id"] == file_id for version in available_versions(item))
        self.update_file_selection()
        self.update_subtitle_selection()
        self.update_audio_selection()
        self.update_actions()
        if self.hero_episode is None:
            self.show_hero()

    # -------------------------------------------------------------- actions
    def update_actions(self):
        """Work out which buttons show, their labels, and lay the row out."""
        resume = self.update_resume()
        target = self.target()
        # On a series or season page the Next Up capsule plays the next-up episode, and the
        # circles after it act on that episode once its detail is read.
        playable = bool(target) and bool(self.application.is_playable(target))
        start_first = self.application.options()["resume_behavior"] == "start"
        has_file = self.selected_file_id is not None
        self.play_label = "Resume " + format_time(resume) if self.can_resume and not start_first else "Play"
        shown = {
            NEXT_UP: bool(self.plays_next_up() and self.item.get("play_content_id")),
            PLAY: playable and not self.plays_next_up(),
            # With "start", Play starts over, so Resume needs its own button.
            RESUME: self.can_resume and start_first,
            START_OVER: self.can_resume,
            VERSION: playable and len(available_versions(target)) > 1,
            AUDIO: playable and len(self.audio_options()) > 1,
            SUBTITLES: playable and bool(self.subtitle_options()),
            WATCHLIST: bool(self.item.get("content_id")),
            FAVORITE: bool(self.item.get("content_id")),
            MORE: bool(self.item.get("content_id")),
        }
        marks = svc_personal.state(self.item)
        set_properties(self, {
            "silo.playable": "true" if shown[PLAY] else "",
            "silo.choosers": "true" if playable else "",
            "silo.play_label": self.play_label,
            "silo.resume_button": "true" if shown[RESUME] else "",
            "silo.multi_version": "true" if shown[VERSION] else "",
            "silo.continue": "true" if shown[NEXT_UP] else "",
            "silo.marks": "true" if shown[MORE] else "",
            "silo.in_watchlist": "true" if marks["watchlist"] else "",
            "silo.favorite": "true" if marks["favorite"] else "",
        })
        self.update_next_up_label()
        needs_file = (PLAY, RESUME, START_OVER, VERSION)
        self.visible_buttons = [control_id for control_id in BUTTON_ORDER if shown[control_id]]
        self.focusable_buttons = [control_id for control_id in self.visible_buttons
                                  if has_file or control_id not in needs_file]
        self.layout_buttons()

    def next_up_episode(self):
        content_id = self.item.get("play_content_id")
        if not content_id:
            return None
        if self.next_up:
            return self.next_up
        for episodes in [self.episodes] + list(self.episode_cache.values()):
            for episode in episodes:
                if episode.get("content_id") == content_id:
                    return episode
        return None

    def update_next_up_label(self):
        if self.next_up:
            # The episode's own progress, read as Play reads it ("start" plays from the beginning).
            start_first = self.application.options()["resume_behavior"] == "start"
            verb = "Resume" if self.can_resume and not start_first else "Play"
        else:
            verb = "Resume" if resume_position(self.item) > 0 else "Play"
        episode = self.next_up_episode() or {}
        season, number = episode.get("season_number"), episode.get("episode_number")
        if self.item.get("type") == "series" and season is not None and number is not None:
            label = "{} S{}:E{}".format(verb, season, number)
        elif number is not None:
            label = "{} E{}".format(verb, number)
        else:
            label = verb
        self.continue_label = label
        self.setProperty("silo.continue_label", label)

    def layout_buttons(self):
        x = LEFT
        for control_id in self.visible_buttons:
            if control_id in CAPSULES:
                width = capsule_width(self.continue_label if control_id == NEXT_UP else self.play_label)
                self.getControl(control_id).setWidth(width)
            else:
                width = CIRCLE
            self.getControl(1300 + control_id).setPosition(x, BUTTON_TOP)
            x += width + BUTTON_GAP

    def hint(self, control_id):
        """Android widens a focused circle to name it; Kodi shows a line below."""
        if control_id == RESUME:
            return self.resume_label
        if control_id == START_OVER:
            return "Start over"
        if control_id == VERSION:
            version = default_version(self.target(), preferred_file_id=self.selected_file_id)
            return "Version: " + version_label(version) if version else ""
        if control_id == SUBTITLES:
            return self.subtitle_label
        if control_id == AUDIO:
            return self.audio_label
        marks = svc_personal.state(self.item)
        if control_id == WATCHLIST:
            return "Remove from watchlist" if marks["watchlist"] else "Add to watchlist"
        if control_id == FAVORITE:
            return "Remove from favorites" if marks["favorite"] else "Add to favorites"
        if control_id == MORE:
            return "More"
        return ""

    # ----------------------------------------------------------------- hero
    def show_hero(self, episode=None):
        """Fill the hero from the page item, or from a focused episode."""
        item = episode or self.item
        image = self.application.image
        is_episode = episode is not None or item.get("type") == "episode"
        if episode is not None:
            supertitle = _text(self.item.get("title") or self.item.get("name"))
        else:
            supertitle = _text(item.get("series_title")) if is_episode else ""
        title, title2 = split_title(_text(item.get("title") or item.get("name")) or "Untitled")
        version = None if episode is not None else default_version(item, preferred_file_id=self.selected_file_id)
        rating = _text(item.get("content_rating") or (self.item.get("content_rating") if episode else ""))
        overview = _text(item.get("overview") or item.get("description")) if self.show_plot else ""
        if episode is not None and self.spoiler_hidden(episode):
            overview = ""
        values = {
            "silo.supertitle": supertitle,
            "silo.title": title.upper(),
            "silo.title2": title2.upper(),
            "silo.logo": "" if is_episode else image(item, "logo"),
            "silo.rating": rating,
            "silo.meta": present.detail_meta(item),
            "silo.plot": overview,
            "silo.plot_more": "true" if len(overview) > PLOT_PREVIEW else "",
            # The credit stays the page's own so the rows below never jump.
            "silo.credit": present.credit_line(self.item),
        }
        if episode is None:
            values["silo.backdrop"] = image(item, "backdrop")
        self.hero_overview = overview
        set_properties(self, values)
        self.layout_title(bool(supertitle), bool(title2))
        self.layout_meta(rating, [badge for badge in present.badges(item, version) if badge != rating])

    def layout_title(self, has_supertitle, has_second_line):
        bottom = TITLE_BOTTOM
        if has_second_line:
            bottom -= 50
            self.getControl(TITLE2).setPosition(LEFT, bottom)
        bottom -= 80
        self.getControl(TITLE).setPosition(LEFT, bottom)
        if has_supertitle:
            self.getControl(SUPERTITLE).setPosition(LEFT, bottom - 40)

    def layout_meta(self, rating, badges):
        """Rating chip, then quality badges, then the facts text on one line."""
        x = LEFT
        if rating:
            width = chip_width(rating)
            for control_id in (CHIP, CHIP_LABEL):
                self.getControl(control_id).setPosition(x, META_TOP)
                self.getControl(control_id).setWidth(width)
            x += width + 14
        badges = badges[:MAX_BADGES]
        for slot in range(MAX_BADGES):
            text = badges[slot] if slot < len(badges) else ""
            self.setProperty("silo.badge.{}".format(slot), text)
            if text:
                width = present.badge_width(text)
                for control_id in (BADGE + slot, BADGE_LABEL + slot):
                    self.getControl(control_id).setPosition(x, META_TOP)
                    self.getControl(control_id).setWidth(width)
                x += width + 10
        if x > LEFT:
            x += 4
        meta = self.getControl(META)
        meta.setPosition(x, META_TOP)
        meta.setWidth(max(1, TEXT_RIGHT - x))

    def spoiler_hidden(self, episode):
        return self.hide_spoilers and is_unwatched(episode)

    def show_focused_episode(self):
        episode = self.selected(EPISODES, self.episodes)
        if episode is not None and episode is not self.hero_episode:
            self.hero_episode = episode
            self.show_hero(episode)

    # ------------------------------------------------------ seasons/episodes
    def load_children(self):
        kind = self.item.get("type")
        if kind == "series":
            self.seasons = present.ordered_seasons(self.children)
            self.setProperty("silo.has_seasons", "true" if self.seasons else "")
            if self.seasons:
                self.season_index = present.initial_season_index(self.item, self.seasons)
                control = self.getControl(SEASONS)
                control.reset()
                control.addItems([xbmcgui.ListItem(label=present.season_label(season)) for season in self.seasons])
                control.selectItem(self.season_index)
                self.show_season(self.season_index)
                return
        elif kind == "season":
            self.setProperty("silo.has_seasons", "")
            self.set_episodes([dict(child, type="episode") for child in self.children if isinstance(child, dict)])
            return
        self.setProperty("silo.has_seasons", "")
        self.set_episodes([])

    def season_settled(self):
        """Load the season the capsule row settled on."""
        if not self.seasons:
            return
        position = self.getControl(SEASONS).getSelectedPosition()
        if 0 <= position < len(self.seasons) and position != self.season_index:
            self.season_index = position
            self.show_season(position)

    def season_episodes(self, index):
        """A season's episodes, read once; a failed read is not kept."""
        season = self.seasons[index]
        key = season.get("content_id")
        episodes = self.episode_cache.get(key)
        if episodes is None:
            episodes = self.application.guard(lambda: self.application.episodes(season))
            if not isinstance(episodes, list):
                return []
            self.episode_cache[key] = episodes
        return episodes

    def show_season(self, index):
        episodes = self.season_episodes(index)
        if index == self.season_index:
            self.set_episodes(episodes)

    def cross_season(self, action_id):
        """Right on a season's last episode moves on to the next season's first, and Left on its
        first back to the previous season's last, passing over empty seasons (Android's episode
        carousel). Kodi has already moved the selection, so only a press that did not move it
        counts as one at the end. True when the rail crossed."""
        position = self.getControl(EPISODES).getSelectedPosition()
        moved, self.rail_position = position != self.rail_position, position
        step = 1 if action_id == ACTION_RIGHT else -1
        if moved or not self.seasons or position != (len(self.episodes) - 1 if step > 0 else 0):
            return False
        index = self.season_index + step
        while 0 <= index < len(self.seasons):
            episodes = self.season_episodes(index)
            if episodes:
                break
            index += step
        else:
            return False
        self.season_index = index
        self.getControl(SEASONS).selectItem(index)
        self.set_episodes(episodes, select=0 if step > 0 else len(episodes) - 1)
        return True

    def reload_episodes(self):
        """Progress changed after playback; fetch the shown season again."""
        if self.seasons:
            self.episode_cache.pop(self.seasons[self.season_index].get("content_id"), None)
            self.show_season(self.season_index)

    def set_episodes(self, episodes, select=None):
        """Show a season's episodes, selecting ``select`` or else the next-up episode."""
        self.episodes = [episode for episode in episodes if isinstance(episode, dict)]
        control = self.getControl(EPISODES)
        control.reset()
        entries = []
        for episode in self.episodes:
            entry = card_list_item(episode, self.application.image, wide=True)
            first, second = present.episode_caption(episode)
            entry.setLabel(first)
            entry.setLabel2(second)
            if self.spoiler_hidden(episode):
                # Spoiler protection: no still and no synopsis until the episode is started.
                entry.setArt({"thumb": "", "poster": "", "fanart": ""})
                entry.setProperty("silo.plot", "")
            entries.append(entry)
        control.addItems(entries)
        play_id = self.item.get("play_content_id")
        position = next((index for index, episode in enumerate(self.episodes)
                         if play_id and episode.get("content_id") == play_id), 0)
        if select is not None and 0 <= select < len(self.episodes):
            position = select
        if self.episodes:
            control.selectItem(position)
        self.rail_position = position if self.episodes else None
        self.setProperty("silo.has_episodes", "true" if self.episodes else "")
        if self.hero_episode is not None:
            self.hero_episode = None
            if self.focused() == EPISODES:
                self.show_focused_episode()
            else:
                self.show_hero()
        if self.initialized:
            self.update_next_up_label()
            self.layout_buttons()
            self.layout_sections()

    # ------------------------------------------------------- cast & similar
    def photo(self, url):
        url = _text(url)
        if not url:
            return ""
        if urlsplit(url).scheme == "https":
            return url
        return self.application.image({"poster_url": url}, "poster")

    def load_cast(self):
        credits = self.item.get("cast") if isinstance(self.item.get("cast"), list) else []
        self.cast = [person for person in credits if isinstance(person, dict) and _text(person.get("name"))][:MAX_CAST]
        entries = []
        for person in self.cast:
            name = _text(person["name"])
            entry = xbmcgui.ListItem(label=name, label2=_text(person.get("character")))
            photo = self.photo(person.get("photo_url"))
            if photo:
                entry.setArt({"thumb": photo})
            entry.setProperty("silo.initials", present.initials(name))
            entries.append(entry)
        control = self.getControl(CAST)
        control.reset()
        control.addItems(entries)
        self.setProperty("silo.has_cast", "true" if self.cast else "")

    def load_similar(self):
        try:
            items = self.application.similar(self.item)
        except Exception:  # The row is optional; never let it break the page.
            items = []
        self.similar = present.video_items(items) if isinstance(items, list) else []
        control = self.getControl(SIMILAR)
        control.reset()
        control.addItems([card_list_item(item, self.application.image) for item in self.similar])
        self.setProperty("silo.has_similar", "true" if self.similar else "")
        self.layout_sections()

    # ---------------------------------------------------------------- box set
    def load_box_set(self):
        """A movie's box set: its movies in release order, then Explore all (Android TvBoxSetRow)."""
        found = None
        if self.item.get("type") == "movie" and self.item.get("content_id"):
            try:
                if self.application.box_sets_on():
                    found = svc_boxsets.for_item(self.application.client, self.item["content_id"])
            except Exception:  # The row is optional; never let it break the page.
                found = None
        self.show_box_set(found, explore=True)

    def show_box_set(self, found, explore, title=None, select=None):
        """Fill the box set row. On a movie's page the film on screen is tagged and selected."""
        self.box_set = found["box_set"] if found else None
        self.box_set_movies = found["items"] if found else []
        self.box_set_explore = bool(explore and self.box_set_movies)
        current = self.item.get("content_id")
        entries = []
        for movie in self.box_set_movies:
            entry = card_list_item(movie, self.application.image)
            entry.setProperty("silo.marked", "true" if explore and movie.get("content_id") == current else "")
            entries.append(entry)
        if self.box_set_explore:
            entry = xbmcgui.ListItem(label="Explore all", label2=svc_boxsets.film_count(self.box_set["movie_count"]))
            entry.setProperty("silo.explore", "true")
            entries.append(entry)
        control = self.getControl(BOXSET)
        control.reset()
        control.addItems(entries)
        if select is None:
            select = next((index for index, movie in enumerate(self.box_set_movies)
                           if explore and movie.get("content_id") == current), 0)
        if entries:
            control.selectItem(max(0, min(select, len(entries) - 1)))
        self.setProperty("silo.boxset_title", title or (self.box_set or {}).get("title", ""))
        self.setProperty("silo.has_boxset", "true" if self.box_set_movies else "")
        self.layout_sections()

    def open_box_set_card(self):
        position = self.getControl(BOXSET).getSelectedPosition()
        if self.box_set_explore and position == len(self.box_set_movies):
            self.application.open_screen("box_set", box_set_id=self.box_set["id"],
                                         library_id=self.box_set["library_id"])
        elif 0 <= position < len(self.box_set_movies):
            movie = self.box_set_movies[position]
            if movie.get("content_id") != self.item.get("content_id"):
                self.application.open_item(movie)

    # ---------------------------------------------------------- collections
    def load_collections(self):
        """The collections holding a movie or series (Android TvItemCollectionsRow): one
        collection's other titles then Explore all, or an "Also in" row of collection cards."""
        found = None
        if self.item.get("type") in ("movie", "series") and self.item.get("content_id"):
            try:
                found = svc_browse.item_collections(self.application.client, self.item["content_id"])
            except Exception:  # The row is optional; never let it break the page.
                found = None
        cards = (found or {}).get("cards") or []
        self.collection_cards = cards
        self.collection_preview = ((found or {}).get("preview") or []) if len(cards) == 1 else []
        image = self.application.image
        if self.collection_preview:
            entries = [card_list_item(item, image) for item in self.collection_preview]
            explore = xbmcgui.ListItem(label="Explore all", label2=present.count_text(cards[0].get("count")))
            explore.setProperty("silo.explore", "true")
            entries.append(explore)
            title = cards[0]["title"]
        else:
            entries = [collection_list_item(card, image) for card in cards]
            title = "Also in" if cards else ""
        control = self.getControl(COLLECTIONS)
        control.reset()
        control.addItems(entries)
        if entries:
            control.selectItem(0)
        self.setProperty("silo.collections_title", title)
        self.setProperty("silo.has_collections", "true" if cards else "")
        self.layout_sections()

    def open_collections_card(self):
        position = self.getControl(COLLECTIONS).getSelectedPosition()
        if self.collection_preview:
            if 0 <= position < len(self.collection_preview):
                self.application.open_item(self.collection_preview[position])
            elif position == len(self.collection_preview):
                self.application.open_screen("collection", collection=self.collection_cards[0])
        elif 0 <= position < len(self.collection_cards):
            self.application.open_screen("collection", collection=self.collection_cards[position])

    def layout_sections(self):
        """Stack the sections below the rail in zone order: cast, trailers, box set, collections
        (right below the cast on a series), related, then details."""
        has_rail = bool(self.seasons or self.episodes)
        top = SECTIONS_TOP_SERIES if has_rail else SECTIONS_TOP
        heights = {"cast": CAST_HEIGHT if self.cast else 0, "extras": EXTRAS_HEIGHT if self.extras else 0,
                   "boxset": BOXSET_HEIGHT if self.box_set_movies else 0,
                   "collections": COLLECTIONS_HEIGHT if self.collection_cards else 0,
                   "similar": SIMILAR_HEIGHT if self.similar else 0}
        tops = {}
        for zone in self.zone_order():
            if zone in heights:
                tops[zone] = top
                top += heights[zone]
        self.cast_top, self.extras_top, self.boxset_top = tops["cast"], tops["extras"], tops["boxset"]
        self.collections_top, self.similar_top, self.facts_top = tops["collections"], tops["similar"], top
        for group, group_top in ((CAST_GROUP, self.cast_top), (EXTRAS_GROUP, self.extras_top),
                                 (BOXSET_GROUP, self.boxset_top), (COLLECTIONS_GROUP, self.collections_top),
                                 (SIMILAR_GROUP, self.similar_top), (FACTS_GROUP, self.facts_top)):
            self.getControl(group).setPosition(0, group_top)

    # ----------------------------------------------------- trailers & extras
    def youtube_available(self):
        try:
            return bool(xbmc.getCondVisibility("System.HasAddon({})".format(YOUTUBE_ADDON)))
        except (AttributeError, RuntimeError):
            return False

    def load_extras(self):
        self.extras = trailer_entries(self.item, self.youtube_available())
        entries = []
        for extra in self.extras:
            entry = xbmcgui.ListItem(label=extra["title"], label2=extra["label2"])
            thumb = extra.get("thumb") or self.photo(extra.get("still"))
            if thumb:
                entry.setArt({"thumb": thumb})
            entries.append(entry)
        control = self.getControl(EXTRAS)
        control.reset()
        control.addItems(entries)
        self.setProperty("silo.has_extras", "true" if self.extras else "")

    def play_extra(self, entry):
        if entry["source"] == "youtube":
            # Trailers hand off to Kodi's YouTube add-on; the row hides them without it.
            # They do not go through Silo's player, so stop the theme here first.
            theme = getattr(self.application, "_theme", None)
            if theme is not None:
                theme.yield_to()
            xbmc.Player().play(YOUTUBE_PLAY.format(quote(entry["key"], safe="")))
            return
        # A local extra is a catalog item of type "extra" with its own versions.
        item = self.application.client.item(entry["extra"]["content_id"])
        if not isinstance(item, dict):
            return
        if not self.application.is_playable(item) and item.get("type") == "extra":
            item = dict(item, type="movie")  # Plays as a single title: no Up Next, no series context.
        self.application.play(item)

    # ---------------------------------------------------------------- facts
    def load_facts(self):
        version = default_version(self.item, preferred_file_id=self.selected_file_id)
        self.facts = facts(self.item, version)
        control = self.getControl(FACTS)
        control.reset()
        control.addItems([xbmcgui.ListItem(label=label.upper(), label2=value) for label, value in self.facts])
        self.setProperty("silo.has_facts", "true" if self.facts else "")

    # ------------------------------------------------------- personal marks
    def set_marks(self, **changes):
        """Apply watchlist/favorite/played changes to the page item locally."""
        keys = {"watchlist": "in_watchlist", "favorite": "is_favorite", "watched": "played"}
        item = dict(self.item)
        for key in ("user_state", "user_data"):
            state = dict(item.get(key) or {}) if isinstance(item.get(key), dict) else {}
            if key == "user_state" or state:
                for name, value in changes.items():
                    if key == "user_state" or keys[name] in state:
                        state[keys[name]] = value
                item[key] = state
        self.item = item

    def toggle_mark(self, kind):
        """Watchlist and Favorite answer 204, so the page flips its own state."""
        on = not svc_personal.state(self.item)[kind]
        setter = svc_personal.set_watchlist if kind == "watchlist" else svc_personal.set_favorite
        setter(self.application.client, self.item["content_id"], on)
        self.set_marks(**{kind: on})
        self.update_actions()
        self.setProperty("silo.hint", self.hint(WATCHLIST if kind == "watchlist" else FAVORITE))

    def toggle_watched(self):
        on = not svc_personal.state(self.item)["watched"]
        svc_personal.set_watched(self.application.client, self.item["content_id"], on)
        # Marking resets progress on the server; read the page and its episodes again.
        for season in self.seasons:
            season["user_data"] = dict(season.get("user_data") or {}, played=on)
        self.refresh(self.selected_file_id)
        self.reload_children()

    def rate(self):
        """Pick 5 down to 1 stars, or remove the rating; saved to the profile."""
        current = svc_personal.rating(self.item)
        # A half-star rating made in another Silo app matches no choice here.
        choices = list(range(10, 0, -2)) + ([None] if current else [])
        labels = [stars_label(score) if score else "Remove rating" for score in choices]
        chosen = self.application.dialog.select("Rate " + (_text(self.item.get("title")) or "this title"), labels,
                                                preselect=choices.index(current) if current in choices else -1)
        if not isinstance(chosen, int) or not 0 <= chosen < len(choices) or choices[chosen] == current:
            return
        score = choices[chosen]
        svc_personal.set_rating(self.application.client, self.item["content_id"], score)
        self.item = dict(self.item, user_rating=score)
        self.application.dialog.notification(
            "Founders Theater", "Rated " + stars_label(score) if score else "Rating removed", time=2500, sound=False)

    def set_season_watched(self, season, on):
        svc_personal.set_watched(self.application.client, season["content_id"], on)
        season["user_data"] = dict(season.get("user_data") or {}, played=on)
        self.refresh(self.selected_file_id)
        self.episode_cache.pop(season.get("content_id"), None)
        if self.seasons and self.seasons[self.season_index] is season:
            self.show_season(self.season_index)

    def reload_children(self):
        """Episodes changed on the server: drop the cache and show them again."""
        if self.item.get("type") == "season":
            episodes = self.application.guard(lambda: self.application.episodes(self.item))
            if isinstance(episodes, list):
                self.set_episodes(episodes)
        elif self.seasons:
            self.episode_cache.clear()
            self.show_season(self.season_index)

    # ------------------------------------------------------------ More menu
    def current_season(self):
        if self.item.get("type") == "series" and self.seasons and 0 <= self.season_index < len(self.seasons):
            return self.seasons[self.season_index]
        return None

    def can_shuffle(self, kind):
        if self.shuffle_kinds is None:
            try:
                document = svc_shuffle.capability(self.application.client)
            except Exception:  # Without the capability the menu just leaves shuffle out.
                document = {}
            kinds = document.get("scope_kinds") if document.get("state") == "available" else None
            self.shuffle_kinds = [kind for kind in kinds or [] if isinstance(kind, str)]
        return kind in self.shuffle_kinds

    def can_host_party(self):
        if self.party_support is None:
            try:
                self.party_support = svc_party.support(self.application.client)
            except Exception:  # Without the capability the menu just leaves Watch Party out.
                self.party_support = {}
        return bool(self.party_support.get("host"))

    def host_party(self, item):
        self.application.open_screen("host_party", item=item, file_id=self.selected_file_id)

    def can_translate(self):
        if not _text(self.item.get("pending_translation_language")):
            return False
        if self.metadata_ai is None:
            try:
                document = self.application.client.request("GET", "/capabilities/metadata-ai")
            except Exception:  # Translation is optional; hide it when the server says nothing.
                document = None
            self.metadata_ai = document if isinstance(document, dict) else {}
        return self.metadata_ai.get("state") == "available" and self.metadata_ai.get("on_view", "off") != "off"

    def more_actions(self):
        """The More menu as (label, action) pairs, in the Android order."""
        item, actions = self.item, []
        kind, content_id = item.get("type"), item.get("content_id")
        season = self.current_season()
        if kind == "series" and self.can_shuffle("series"):
            actions.append(("Shuffle series", lambda: self.shuffle(series_id=content_id)))
        if season is not None and self.can_shuffle("season"):
            actions.append(("Shuffle " + present.season_label(season),
                            lambda: self.shuffle(season_id=season["content_id"])))
        if kind == "season" and self.can_shuffle("season"):
            actions.append(("Shuffle season", lambda: self.shuffle(season_id=content_id)))
        # A series or season page hosts its next-up episode, in the version on screen.
        party_item = self.target()
        if party_item.get("type") in ("movie", "episode") and self.can_host_party():
            actions.append(("Watch Party", lambda: self.host_party(party_item)))
        watched = svc_personal.state(item)["watched"]
        actions.append(("Mark as unwatched" if watched else "Mark as watched", self.toggle_watched))
        if season is not None:
            played = (season.get("user_data") or {}).get("played") is True
            actions.append(("Mark {} as {}".format(present.season_label(season), "unwatched" if played else "watched"),
                            lambda: self.set_season_watched(season, not played)))
        series_id = _text(item.get("series_id"))
        if kind == "episode" and series_id:
            number = item.get("season_number")
            if isinstance(number, int) and not isinstance(number, bool) and number > 0:
                actions.append(("Go to season {}".format(number), self.go_to_season))
        if kind in ("episode", "season") and series_id:
            actions.append(("Go to series", self.go_to_series))
        if kind in RATED_KINDS:
            stars = svc_personal.rating(item)
            actions.append(("Rate ({})".format(stars_label(stars)) if stars else "Rate", self.rate))
        if default_version(item, preferred_file_id=self.selected_file_id):
            actions.append(("Media info", self.show_media_info))
        if self.can_translate():
            actions.append(("Translate description", self.translate_description))
        return actions

    def open_more(self):
        actions = self.more_actions()
        chosen = self.application.dialog.contextmenu([label for label, _ in actions])
        if isinstance(chosen, int) and 0 <= chosen < len(actions):
            actions[chosen][1]()

    def shuffle(self, **scope):
        played = svc_shuffle.play_shuffle(self.application, **scope)
        if played:
            self.refresh(self.selected_file_id)
            self.reload_children()

    def go_to_series(self):
        self.application.open_item({"content_id": self.item["series_id"]})

    def go_to_season(self):
        series_id, number = self.item["series_id"], self.item.get("season_number")
        response = self.application.client.seasons(series_id) or {}
        season = next((entry for entry in response.get("items", [])
                       if isinstance(entry, dict) and entry.get("season_number") == number
                       and entry.get("content_id")), None)
        self.application.open_item(dict(season, type="season") if season else {"content_id": series_id})

    def show_media_info(self):
        version = default_version(self.item, preferred_file_id=self.selected_file_id)
        self.application.dialog.textviewer("Media info", media_info_text(version))

    def translate_description(self):
        language = _text(self.item.get("pending_translation_language"))
        self.application.client.request(
            "POST", "/catalog/items/{}/translate-description".format(quote(str(self.item["content_id"]), safe="")),
            body={"target_language": language})
        # The server translates in the background; read the page once more.
        self.refresh(self.selected_file_id)
        if _text(self.item.get("pending_translation_language")):
            self.application.dialog.notification("Silo", "The translated description will appear when it is ready.")

    # ----------------------------------------------------------- navigation
    def focused(self):
        try:
            return self.getFocusId()
        except (AttributeError, RuntimeError):
            return self.focus_id

    def focus_control(self, control_id):
        self.focus_id = control_id
        self.setFocusId(control_id)

    def zone_of(self, control_id):
        if control_id in BUTTON_ORDER:
            return "buttons"
        return next((zone for zone, zone_control in ZONE_CONTROLS.items() if zone_control == control_id), None)

    def available_zones(self):
        present_zones = {
            "synopsis": len(self.hero_overview) > PLOT_PREVIEW,
            "buttons": bool(self.focusable_buttons),
            "seasons": bool(self.seasons),
            "episodes": bool(self.episodes),
            "cast": bool(self.cast),
            "extras": bool(self.extras),
            "boxset": bool(self.box_set_movies),
            "collections": bool(self.collection_cards),
            "similar": bool(self.similar),
            "facts": bool(self.facts),
        }
        return [zone for zone in self.zone_order() if present_zones[zone]]

    def zone_order(self):
        return SERIES_ZONES if self.item.get("type") == "series" else ZONES

    def move_zone(self, step):
        zones = self.available_zones()
        current = self.zone_of(self.focused())
        if not zones:
            return
        if current not in zones:
            target = zones[0]
        else:
            index = zones.index(current) + step
            if not 0 <= index < len(zones):
                return
            target = zones[index]
        self.focus_zone(target)

    def focus_zone(self, zone):
        if zone == "buttons":
            if self.last_button in self.focusable_buttons:
                control_id = self.last_button
            elif PLAY in self.focusable_buttons:
                control_id = PLAY
            else:
                control_id = self.focusable_buttons[0]
        else:
            control_id = ZONE_CONTROLS[zone]
        self.focus_control(control_id)
        self.scroll_to(zone)

    def scroll_to(self, zone):
        tops = {"cast": self.cast_top, "extras": self.extras_top, "boxset": self.boxset_top,
                "collections": self.collections_top, "similar": self.similar_top, "facts": self.facts_top}
        offset = max(0, tops[zone] - SECTION_SCROLL_TOP) if zone in tops else 0
        if offset != self.scroll_offset:
            self.scroll_offset = offset
            self.getControl(PAGE).setPosition(0, -offset)


class BoxSetWindow(DetailsWindow):
    """One box set (Android TvBoxSetScreen): the details hero with Play on the next movie to
    watch, then the box set's movies in release order. Coming back from a movie or the
    player reads the box set again, so the watched count and Play follow."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.box_set_id = None
        self.library_id = None
        self.found = None

    def onInit(self):
        if self.initialized:
            return
        self.initialized = True
        self.show_plot = self.application.options()["show_plot"]
        self.show_found()
        if PLAY in self.focusable_buttons:
            self.focus_control(PLAY)
        elif self.box_set_movies:
            self.focus_zone("boxset")

    def show_found(self, select=None):
        box_set = self.found["box_set"]
        self.item = {"type": "box_set", "title": box_set["title"], "overview": box_set["overview"]}
        self.show_box_set(self.found, explore=False, title="Movies", select=select)
        self.update_actions()
        self.show_hero()

    def update_actions(self):
        movies = self.box_set_movies
        self.play_label = svc_boxsets.play_label(self.box_set, movies) if movies else ""
        set_properties(self, {
            "silo.playable": "true" if movies else "",
            "silo.has_file": "true" if movies else "",
            "silo.play_label": self.play_label,
            "silo.resume": "", "silo.resume_button": "", "silo.multi_version": "", "silo.continue": "",
            "silo.marks": "", "silo.has_subtitles": "", "silo.has_audio_choice": "", "silo.choosers": "",
        })
        self.visible_buttons = [PLAY] if movies else []
        self.focusable_buttons = list(self.visible_buttons)
        self.layout_buttons()

    def show_hero(self, episode=None):
        box_set = self.box_set
        title, title2 = split_title(box_set["title"])
        overview = box_set["overview"] if self.show_plot else ""
        self.hero_overview = overview
        set_properties(self, {
            "silo.supertitle": "", "silo.title": title.upper(), "silo.title2": title2.upper(), "silo.logo": "",
            "silo.rating": "", "silo.meta": svc_boxsets.hero_facts(box_set), "silo.plot": overview,
            "silo.plot_more": "true" if len(overview) > PLOT_PREVIEW else "", "silo.credit": "",
            "silo.backdrop": self.application.image(box_set, "backdrop"),
        })
        self.layout_title(False, bool(title2))
        self.layout_meta("", [])

    def _click(self, control_id):
        if control_id == PLAY:
            self.play_box_set()
        elif control_id == BOXSET:
            movie = self.selected(BOXSET, self.box_set_movies)
            if movie is not None:
                self.application.open_item(movie)
                self.reload()
        elif control_id == READ_MORE:
            super()._click(control_id)

    def open_card_menu(self):
        """Long-press on one of the box set's movies: watched, watchlist and favorite."""
        if self.focused() != BOXSET:
            return
        movie = self.selected(BOXSET, self.box_set_movies)
        if movie is not None and card_menu(self.application, movie) == "watched":
            self.reload()  # Play and the watched count follow.

    def play_box_set(self):
        """Play the next movie to watch; the profile's resume setting decides where it starts."""
        movie = svc_boxsets.next_movie(self.box_set_movies)
        if movie is None:
            return
        item = self.application.client.item(movie["content_id"])
        if isinstance(item, dict):
            self.application.play(item)
        self.reload()

    def reload(self):
        position = self.getControl(BOXSET).getSelectedPosition()
        found = self.application.guard(lambda: svc_boxsets.load(self.application.client, self.box_set_id,
                                                                self.library_id))
        if found and found["items"]:
            self.found = found
            self.show_found(select=position)


def open_box_set(application, box_set_id, library_id):
    """Open one box set of one library; a 404 means box sets are off there or too few movies remain."""
    try:
        found = svc_boxsets.load(application.client, box_set_id, library_id)
    except ApiError as exc:
        if exc.status != 404:
            raise
        found = None
    if not found or not found["items"]:
        application.dialog.ok("Box set", BOX_SET_UNAVAILABLE)
        return
    window = BoxSetWindow("SiloDetails.xml", application.addon.getAddonInfo("path"), "Default", "1080i")
    window.application, window.box_set_id, window.library_id, window.found = (application, box_set_id,
                                                                              library_id, found)
    window.doModal()
    del window
