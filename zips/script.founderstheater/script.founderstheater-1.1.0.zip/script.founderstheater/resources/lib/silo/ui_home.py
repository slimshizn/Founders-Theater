"""The home screen: top bar, hero and rows, library grids and search."""

import json
import threading
from urllib.parse import quote

import xbmcgui

from . import catalog_controls as controls, present, svc_boxsets, svc_personal
from .catalog_controls import SORTS, active_facets, filter_groups
from .media import resume_position
from .ui_common import (ACTION_DOWN, ACTION_LEFT, ACTION_MOUSE_MOVE, ACTION_RIGHT, ACTION_UP, BACK_ACTIONS,
                        CONTEXT_ACTIONS, Debouncer, box_set_list_item, card_list_item, card_menu, collection_list_item,
                        search_heading, set_properties, update_card)

# Control ids; scripts/skin_home.py writes the matching SiloHome.xml.
TOP_BAR, TAB_CLUSTER, SEARCH_BUTTON, AVATAR = 200, 202, 201, 230
# (tab, button, group, width) in Android order; the cluster is centred with a search-sized spacer
# after the last shown tab. Library tabs need a library, Requests needs the server feature.
TABS = (("home", 210, 215, 124), ("movies", 211, 216, 148), ("series", 212, 217, 140),
        ("for_you", 203, 206, 156), ("calendar", 204, 207, 172), ("requests", 205, 208, 172))
TAB_KINDS = {"movies": "movie", "series": "series"}
TAB_BUTTONS = {tab: button for tab, button, _group, _width in TABS}
LIBRARY_TABS = {TAB_BUTTONS["movies"]: "movie", TAB_BUTTONS["series"]: "series"}
# Tabs that open another screen modally; Home stays the selected tab.
SCREEN_TABS = {TAB_BUTTONS["for_you"]: "for_you", TAB_BUTTONS["calendar"]: "calendar",
               TAB_BUTTONS["requests"]: "requests"}
SEARCH_SIZE, SEARCH_GAP, TAB_GAP, SCREEN_WIDTH, SCREEN_HEIGHT = 56, 24, 8, 1920, 1080
# The add-on's name sits at x 88 in font36_title (about 380 px wide); the tab group
# stays centred but never starts closer to the name than this.
TABS_MIN_LEFT = 88 + 380 + 40
BAR_CONTROLS = frozenset([SEARCH_BUTTON, AVATAR] + [tab[1] for tab in TABS])

HOME_GROUP, HERO_GROUP, HERO_META = 300, 400, 430
BADGE_IMAGES, BADGE_LABELS = (411, 412, 413, 414), (421, 422, 423, 424)
HERO_LEFT, BADGE_TOP, BADGE_GAP, NO_SYNOPSIS_SHIFT = 88, 346, 12, 84

# Row slot k: group SLOT_BASE + 10k, header +1, play icon +2, wide list +3, poster list +4.
SLOTS, SLOT_BASE = 12, 3000
ROWS_TOP, WIDE_PITCH, POSTER_PITCH = 530, 410, 470

BROWSE_GROUP, LIBRARY_GROUP, SEARCH_GROUP, GRID = 700, 710, 800, 500
LIBRARY_CHIP, SORT_CHIP, SEARCH_FIELD = 510, 511, 520
FILTER_CHIP, CLEAR_CHIP, SHUFFLE_CHIP = 516, 517, 518
FILTER_BADGE = 525  # group with the count label 526
CHIPS = (LIBRARY_CHIP, SORT_CHIP, FILTER_CHIP, CLEAR_CHIP, SHUFFLE_CHIP)
CHEVRONS = {LIBRARY_CHIP: (512, 513), SORT_CHIP: (514, 515)}
CHIP_TOP, CHIP_GAP, BADGE_SIZE = 188, 16, 32
GRID_LEFT, LIBRARY_GRID_TOP, SEARCH_GRID_TOP = 40, 270, 370
SEARCH_CHIPS = {530: "video", 531: "movie", 532: "series"}
# Box sets are movies, so they lead the All and Movies results only (Android TvSearchViewModel).
BOX_SET_SEARCH_TYPES = ("video", "movie")
BOX_SET = "box_set"
COLLECTION = present.COLLECTION  # a card in a home row of collections
LOAD_AHEAD = 12

# A–Z jump rail beside the grid while it is sorted by title (Android TvAlphabetRail).
RAIL, RAIL_GROUP = 560, 565
RAIL_LETTERS = ("All", "#") + tuple(chr(code) for code in range(ord("A"), ord("Z") + 1))

# Search: a People row above the title grid.
PEOPLE_GROUP, PEOPLE_LIST = 575, 570
PEOPLE_HEIGHT, PEOPLE_LIMIT = 290, 20

# Top-bar panels; scripts/skin_home.py fades them in a moment after a tab takes focus and keeps
# them while focus is inside. Movies/Series: the library cascade (Android TvCascadeSelector), a
# library list then Recommended/Browse/Collections beside the focused library. For You:
# Recommendations, Favorites, Watchlist and History (TvForYouSelector, plus History).
LIB_PANEL, LIB_PANEL_BG, LIB_LIST, LIB_EXIT = 645, 646, 650, 659
FLYOUT, FLYOUT_BG, FLYOUT_LIST = 655, 656, 660
FOR_YOU_PANEL, FOR_YOU_EXIT = 675, 679
FOR_YOU_ITEMS = {670: "for_you", 671: "favorites", 672: "watchlist", 673: "history"}
PANEL_CONTROLS = frozenset([LIB_LIST, FLYOUT_LIST] + list(FOR_YOU_ITEMS))
PANEL_TOP, PANEL_ROW, LIB_WIDTH, FLYOUT_WIDTH, PANEL_GAP, FOR_YOU_WIDTH = 128, 72, 340, 300, 12, 360
SECTION_LABELS = {"recommended": "Recommended", "browse": "Browse", "collections": "Collections"}

MENU, MENU_PANEL = 600, 601
# Avatar menu in Android order.
MENU_ORDER = (610, 618, 613, 614, 615, 611, 616, 617, 612)
MENU_ITEMS = {610: "profile", 618: "watch_party", 613: "watchlist", 614: "favorites", 615: "history",
              611: "settings", 616: "home_rows", 617: "server", 612: "logout"}
MENU_RESULTS = {610: "profile", 611: "settings", 617: "server", 612: "logout"}
MENU_PERSONAL = {613: "watchlist", 614: "favorites", 615: "history"}
MENU_ROW = 72

HOME_ROWS_KEY = "home_rows"


def slot_ids(index):
    base = SLOT_BASE + 10 * index
    return base, base + 1, base + 2, base + 3, base + 4


def chip_width(text, chevron=True):
    """Estimated chip width: text at the 25px bold tab font plus padding and chevron."""
    return 28 + 14 * len(text) + (12 + 24 if chevron else 0) + 28


def total_text(total):
    if isinstance(total, bool) or not isinstance(total, (int, float)):
        return ""
    total = int(total)
    return "{:,} title{}".format(total, "" if total == 1 else "s")


def card_key(item):
    """What identifies a home card across a reload: a title's content id, a collection's id."""
    return item.get("content_id") or item.get("id")


def apply_row_prefs(sections, prefs):
    """Order and hide home sections by the saved editor choices; new rows keep server order after them."""
    prefs = prefs if isinstance(prefs, dict) else {}
    hidden = set(str(value) for value in prefs.get("hidden") or ())
    rank = {str(section_id): index for index, section_id in enumerate(prefs.get("order") or ())}
    known = sorted((section for section in sections if str(section.get("id")) in rank),
                   key=lambda section: rank[str(section.get("id"))])
    rest = [section for section in sections if str(section.get("id")) not in rank]
    return [section for section in known + rest if str(section.get("id")) not in hidden]


class HomeWindow(xbmcgui.WindowXML):
    """Silo's home window; ``result`` is "profile", "settings", "server", "logout" or None."""

    def __init__(self, *args, **kwargs):
        self.application = None
        self.result = None
        self.initialized = False
        self.tab = "home"
        self.sections = []
        self.all_sections = []
        self.row = 0
        self.show_plot = True
        self.hide_spoilers = False
        self.libraries = {"movie": [], "series": []}
        self.requests = False
        self.tab_lefts = {}
        self.cluster_left = 0
        self.menu_open = False
        # The library panel: its kind, its rows (None is "All"), the flyout's sections, and
        # which libraries have collections (absent: not checked yet, so Collections shows).
        self.panel_kind = None
        self.panel_rows = []
        self.flyout_rows = []
        self.flyout_for = None  # The library row the flyout was built for.
        self.collections_known = {}
        self.collection_checks = set()
        # Set when Down left a panel: Kodi reports the focus change before the key, and
        # that Down must not also move on through the page.
        self.left_panel = False
        self.last_focus = None
        self.home_stale = False
        self.kind = "movie"
        self.library = None
        self.sort = "title"
        self.reversed = False
        self.filters = {}
        self.filter_options_cache = {}
        self.letters = None
        self.query = ""
        self.search_type = "video"
        self.people = []
        self.params = None
        self.grid_items = []
        self.cursor = None
        self.generation = 0
        self.series_art_cache = {}
        self.hero_debouncer = Debouncer(self.update_hero)

    # ------------------------------------------------------------ lifecycle

    def onInit(self):
        if self.initialized:
            # Kodi re-runs onInit when a child window closes.
            if self.last_focus:
                self.setFocusId(self.last_focus)
            return
        self.initialized = True
        application = self.application
        options = application.guard(application.options) or {}
        self.show_plot = bool(options.get("show_plot", True))
        self.hide_spoilers = bool(options.get("hide_spoilers", False))
        set_properties(self, {
            "silo.initials": present.initials(application.profile_name),
            "silo.avatar": present.avatar_image(application.profile_avatar),
            "silo.profile_locked": "true" if self.locked() else "",
            "silo.menu": "",
            "silo.panel": "",
            "silo.panel_single": "",
            "silo.rail": "",
            "silo.people": "",
            "silo.filter_count": "",
            "silo.search_type": self.search_type,
        })
        self.getControl(MENU).setVisible(False)
        for kind in self.libraries:
            self.libraries[kind] = application.guard(lambda kind=kind: application.video_libraries(kind)) or []
        self.requests = application.guard(application.requests_enabled) is True
        self.layout_tabs()
        self.fill_rail()
        application.guard(self.load_home)
        self.show_home()

    def close(self):
        self.hero_debouncer.cancel()
        super().close()

    def locked(self):
        return bool(self.application.store.get("temporary_session"))

    def focus_id(self):
        try:
            return self.getFocusId()
        except RuntimeError:
            return 0

    # ------------------------------------------------------------ top bar

    def tab_shown(self, tab):
        if tab in TAB_KINDS:
            return bool(self.libraries[TAB_KINDS[tab]])
        if tab == "requests":
            return self.requests
        return True

    def layout_tabs(self):
        """Hide tabs without content and keep the tab group centred."""
        chain, left = [SEARCH_BUTTON], SEARCH_SIZE + SEARCH_GAP
        self.tab_lefts = {}
        for tab, button, group, width in TABS:
            shown = self.tab_shown(tab)
            self.getControl(group).setVisible(shown)
            self.getControl(button).setVisible(shown)
            if shown:
                self.getControl(group).setPosition(left, 2)
                self.tab_lefts[tab] = left
                left += width + TAB_GAP
                chain.append(button)
        chain.append(AVATAR)
        width = left - TAB_GAP + SEARCH_GAP + SEARCH_SIZE
        self.cluster_left = max((SCREEN_WIDTH - width) // 2, TABS_MIN_LEFT)
        self.getControl(TAB_CLUSTER).setPosition(self.cluster_left, 0)
        for before, after in zip(chain, chain[1:]):
            self.getControl(before).controlRight(self.getControl(after))
            self.getControl(after).controlLeft(self.getControl(before))

    def set_tab(self, tab):
        self.tab = tab
        self.generation += 1  # Pages still loading for the previous tab are dropped.
        self.setProperty("silo.tab", tab)
        # Python visibility applies at once, so focus can move in the same call.
        self.getControl(HOME_GROUP).setVisible(tab == "home")
        self.getControl(BROWSE_GROUP).setVisible(tab != "home")
        self.getControl(LIBRARY_GROUP).setVisible(tab in TAB_KINDS)
        self.getControl(SEARCH_GROUP).setVisible(tab == "search")
        self.update_rail()
        if tab != "search":
            self.show_people([])

    def select_home_tab(self):
        self.set_tab("home")
        if self.home_stale:
            self.home_stale = False
            self.application.guard(self.load_home)

    def focus_tab(self):
        self.setFocusId(TAB_BUTTONS.get(self.tab, SEARCH_BUTTON))

    def focus_content(self):
        if self.tab == "home":
            if self.sections:
                self.focus_row(self.row)
        elif self.tab == "search":
            self.setFocusId(SEARCH_FIELD)
        else:
            self.setFocusId(LIBRARY_CHIP)

    def open_screen_tab(self, control_id):
        """For You, Calendar and Requests open their own screens; Home is the selected tab afterwards."""
        name = SCREEN_TABS[control_id]
        if self.tab != "home":
            self.select_home_tab()
        self.run_modal(lambda: self.application.open_screen(name), control_id)

    # ------------------------------------------------------------ top-bar panels

    def library_name(self, kind, library):
        if library is None:
            return "All movies" if kind == "movie" else "All series"
        return str(library.get("name") or "Library")

    def prepare_panel(self, kind):
        """Fill and place the library panel under the Movies or Series tab (on tab focus)."""
        libraries = self.libraries.get(kind) or []
        tab = "movies" if kind == "movie" else "series"
        single = len(libraries) <= 1
        self.panel_kind = kind
        self.panel_rows = list(libraries) if single else [None] + list(libraries)
        # The check marks the library being browsed, so only while its tab is the current one.
        browsing = self.kind == kind and self.tab == tab
        current = self.library if browsing else None
        items = []
        for library in self.panel_rows:
            item = xbmcgui.ListItem(label=self.library_name(kind, library), offscreen=True)
            item.setProperty("silo.check", "true" if browsing and library == current else "")
            items.append(item)
        rows = self.getControl(LIB_LIST)
        rows.reset()
        rows.addItems(items)
        selected = self.panel_rows.index(current) if browsing and current in self.panel_rows else 0
        rows.selectItem(selected)
        # Room for every row (the last one's gap included) so the list never scrolls under the flyout.
        rows.setHeight(PANEL_ROW * max(1, len(self.panel_rows)))
        self.getControl(LIB_PANEL_BG).setHeight(PANEL_ROW * max(1, len(self.panel_rows)) + 24)
        self.setProperty("silo.panel_single", "true" if single else "")
        left = self.cluster_left + self.tab_lefts.get(tab, 0)
        width = FLYOUT_WIDTH if single else LIB_WIDTH + PANEL_GAP + FLYOUT_WIDTH
        self.getControl(LIB_PANEL).setPosition(max(40, min(left, SCREEN_WIDTH - width - 40)), PANEL_TOP)
        # Up returns to the tab; Left from the first column too (the panel serves both tabs).
        tab_control = self.getControl(TAB_BUTTONS[tab])
        rows.controlUp(tab_control)
        rows.controlLeft(tab_control)
        flyout = self.getControl(FLYOUT_LIST)
        flyout.controlUp(tab_control)
        flyout.controlLeft(tab_control if single else rows)
        self.setProperty("silo.panel", kind)
        self.check_collections(libraries)
        # Kodi applies selectItem later, so reading the selection back here would give the old row.
        self.update_flyout(selected)

    def panel_library(self):
        """The library the flyout belongs to: the only one, or the focused row (None is All)."""
        if self.getProperty("silo.panel_single"):
            return self.panel_rows[0] if self.panel_rows else None
        position = self.flyout_for
        return self.panel_rows[position] if isinstance(position, int) and 0 <= position < len(self.panel_rows) else None

    def has_collections(self, library):
        """False only when every library involved is known to have no collections."""
        if library is not None:
            return self.collections_known.get(library.get("id")) is not False
        libraries = self.libraries.get(self.panel_kind) or []
        return any(self.collections_known.get(entry.get("id")) is not False for entry in libraries)

    def check_collections(self, libraries):
        """Learn in the background which libraries have collections (Android hides the section)."""
        pending = [library for library in libraries
                   if library.get("id") not in self.collections_known and library.get("id") not in self.collection_checks]
        if not pending:
            return
        self.collection_checks.update(library.get("id") for library in pending)
        client = self.application.client

        def work():
            from .svc_browse import library_collections
            for library in pending:
                try:
                    groups = library_collections(client, library["id"])
                except Exception:  # Unknown stays unknown: Collections keeps showing.
                    continue
                self.collections_known[library["id"]] = any(group.get("collections") for group in groups)

        threading.Thread(target=work, name="silo-collections", daemon=True).start()

    def update_flyout(self, position=None):
        """Recommended (one library only), Browse and Collections beside a library row: ``position``,
        or the focused one."""
        self.flyout_for = self.getControl(LIB_LIST).getSelectedPosition() if position is None else position
        library = self.panel_library()
        sections = (["recommended"] if library is not None else []) + ["browse"]
        if self.has_collections(library):
            sections.append("collections")
        self.flyout_rows = sections
        flyout = self.getControl(FLYOUT_LIST)
        flyout.reset()
        flyout.addItems([xbmcgui.ListItem(label=SECTION_LABELS[section], offscreen=True) for section in sections])
        flyout.setHeight(PANEL_ROW * len(sections))
        self.getControl(FLYOUT_BG).setHeight(PANEL_ROW * len(sections) + 24)
        if self.getProperty("silo.panel_single"):
            self.getControl(FLYOUT).setPosition(0, 0)
        else:
            self.getControl(FLYOUT).setPosition(LIB_WIDTH + PANEL_GAP, PANEL_ROW * max(0, self.flyout_for))

    def follow_library_row(self):
        """Rebuild the flyout when the focused library row changed (a mouse hover sends no Up/Down)."""
        if self.getControl(LIB_LIST).getSelectedPosition() != self.flyout_for:
            self.update_flyout()

    def enter_panel(self, kind):
        """Down on Movies or Series moves into its panel (Android: Down hands focus to the selector)."""
        if self.panel_kind != kind:
            self.prepare_panel(kind)
        self.setFocusId(FLYOUT_LIST if self.getProperty("silo.panel_single") else LIB_LIST)

    def place_for_you(self):
        left = self.cluster_left + self.tab_lefts.get("for_you", 0)
        self.getControl(FOR_YOU_PANEL).setPosition(max(40, min(left, SCREEN_WIDTH - FOR_YOU_WIDTH - 40)), PANEL_TOP)

    def panel_tab(self, focus):
        if focus in FOR_YOU_ITEMS:
            return TAB_BUTTONS["for_you"]
        return TAB_BUTTONS["movies" if self.panel_kind == "movie" else "series"]

    def open_flyout(self):
        """Select on a library row moves into its sections, where Browse opens the library."""
        if self.panel_kind is not None:
            self.follow_library_row()
            self.setFocusId(FLYOUT_LIST)

    def choose_section(self):
        kind, library = self.panel_kind, self.panel_library()
        position = self.getControl(FLYOUT_LIST).getSelectedPosition()
        if kind is None or not 0 <= position < len(self.flyout_rows):
            return
        section = self.flyout_rows[position]
        tab_button = TAB_BUTTONS["movies" if kind == "movie" else "series"]
        if section == "browse":
            self.show_library(kind, library)
            self.setFocusId(LIBRARY_CHIP)
        elif section == "recommended":
            self.run_modal(lambda: self.application.open_screen("library_sections", library=library), tab_button)
        elif library is not None:
            self.run_modal(lambda: self.application.open_screen("collections", library=library), tab_button)
        else:
            # All movies / All series: every library of the kind, not only the profile's own collections.
            libraries = list(self.libraries.get(kind) or [])
            self.run_modal(lambda: self.application.open_screen("collections", libraries=libraries), tab_button)

    def choose_for_you(self, control_id):
        choice = FOR_YOU_ITEMS[control_id]
        if choice == "for_you":
            self.open_screen_tab(TAB_BUTTONS["for_you"])
            return
        if self.tab != "home":
            self.select_home_tab()
        self.run_modal(lambda: self.application.open_screen("personal", kind=choice), TAB_BUTTONS["for_you"])

    # ------------------------------------------------------------ avatar menu

    def open_menu(self):
        locked = self.locked()
        self.setProperty("silo.profile_locked", "true" if locked else "")
        self.getControl(610).setVisible(not locked)
        shown = [control for control in MENU_ORDER if not (locked and control == 610)]
        for index, control in enumerate(shown):
            self.getControl(control).setPosition(16, 16 + MENU_ROW * index)
        self.getControl(shown[0]).controlUp(self.getControl(shown[0]))
        self.getControl(MENU_PANEL).setHeight(32 + MENU_ROW * len(shown) - 8)
        self.menu_open = True
        self.setProperty("silo.menu", "true")
        self.getControl(MENU).setVisible(True)
        self.setFocusId(shown[0])

    def close_menu(self, focus=True):
        self.menu_open = False
        self.setProperty("silo.menu", "")
        self.getControl(MENU).setVisible(False)
        if focus:
            self.setFocusId(AVATAR)

    def choose_menu(self, control_id):
        if control_id == 610 and self.locked():
            return
        if control_id in MENU_RESULTS:
            self.result = MENU_RESULTS[control_id]
            self.close()
        elif control_id in MENU_PERSONAL:
            self.close_menu()
            kind = MENU_PERSONAL[control_id]
            self.run_modal(lambda: self.application.open_screen("personal", kind=kind), AVATAR)
        elif control_id == 616:
            self.close_menu()
            self.edit_home_rows()
        elif control_id == 618:
            self.close_menu()
            self.run_modal(lambda: self.application.open_screen("watch_party"), AVATAR)

    # ------------------------------------------------------------ home rows

    def show_home(self):
        self.select_home_tab()
        if self.sections:
            self.focus_row(self.row)
        else:
            self.setFocusId(TABS[0][1])

    def rows_key(self):
        """"<server>|<profile id>", the key home row choices are saved under."""
        application = self.application
        profile = getattr(application, "profile", None)
        profile_id = profile.get("id") if isinstance(profile, dict) else None
        if profile_id in (None, ""):
            profile_id = application.store.get("profile_id")
        server = getattr(getattr(application, "client", None), "server_url", "")
        return "{}|{}".format(server if isinstance(server, str) else "", profile_id or "")

    def row_prefs(self):
        saved = self.application.store.get(HOME_ROWS_KEY)
        prefs = saved.get(self.rows_key()) if isinstance(saved, dict) else None
        return prefs if isinstance(prefs, dict) else {}

    def save_row_prefs(self, order, hidden):
        saved = self.application.store.get(HOME_ROWS_KEY)
        saved = dict(saved) if isinstance(saved, dict) else {}
        saved[self.rows_key()] = {"order": list(order), "hidden": list(hidden)}
        self.application.store.set(HOME_ROWS_KEY, saved)

    def load_home(self):
        sections = self.application.home_sections() or []
        self.all_sections = [section for section in sections if section.get("items")]
        self.apply_sections()

    def apply_sections(self):
        self.sections = apply_row_prefs(self.all_sections, self.row_prefs())[:SLOTS]
        for index in range(SLOTS):
            self.fill_slot(index, self.sections[index] if index < len(self.sections) else None)
        self.row = 0
        self.layout_rows()
        if self.sections:
            self.show_hero(self.sections[0]["items"][0])

    def fill_slot(self, index, section):
        group, header, icon, wide_list, poster_list = slot_ids(index)
        if section is None:
            self.getControl(group).setVisible(False)
            self.getControl(wide_list).reset()
            self.getControl(poster_list).reset()
            return
        wide = present.is_wide_section(section)
        shown, hidden = (wide_list, poster_list) if wide else (poster_list, wide_list)
        self.getControl(hidden).reset()
        self.getControl(hidden).setVisible(False)
        control = self.getControl(shown)
        control.reset()
        control.addItems([collection_list_item(item, self.application.image) if item.get("type") == COLLECTION
                          else card_list_item(item, self.card_image, wide) for item in section["items"]])
        control.setVisible(True)
        self.getControl(header).setLabel(str(section.get("title") or ""))
        self.getControl(header).setPosition(148 if wide else 88, 0)
        self.getControl(icon).setVisible(wide)

    def is_wide(self, index):
        return present.is_wide_section(self.sections[index])

    def row_list(self, index):
        return slot_ids(index)[3 if self.is_wide(index) else 4]

    def row_of(self, control_id):
        offset = control_id - SLOT_BASE
        if offset < 0 or offset % 10 not in (3, 4):
            return None
        index = offset // 10
        return index if index < len(self.sections) else None

    def layout_rows(self):
        """Put the focused row at the top of the rows area; rows above it are hidden."""
        top = ROWS_TOP
        for index in range(SLOTS):
            group = self.getControl(slot_ids(index)[0])
            if index >= len(self.sections) or index < self.row or top >= SCREEN_HEIGHT:
                group.setVisible(False)
                continue
            group.setPosition(0, top)
            group.setVisible(True)
            top += WIDE_PITCH if self.is_wide(index) else POSTER_PITCH

    def focus_row(self, index):
        self.row = index
        self.layout_rows()
        self.setFocusId(self.row_list(index))
        self.hero_debouncer.trigger()

    def card_at(self, control_id):
        """(section id, card key, row, position) of the selected card in a home row, or None."""
        row = self.row_of(control_id)
        if row is None:
            return None
        position = self.getControl(control_id).getSelectedPosition()
        items = self.sections[row]["items"]
        item = items[position] if 0 <= position < len(items) else {}
        return self.sections[row].get("id"), card_key(item), row, position

    def refresh_home(self, card=None):
        """Reload the rows (Android refreshes on resume); refocus the same card when it still exists."""
        sections = self.application.guard(self.application.home_sections)
        if sections is None:
            return False
        self.all_sections = [section for section in sections if section.get("items")]
        self.apply_sections()
        if card is None or not self.sections:
            return False
        section_id, content_id, old_row, old_position = card
        row = next((index for index, section in enumerate(self.sections) if section.get("id") == section_id), None)
        if row is None:
            row, position = min(old_row, len(self.sections) - 1), 0
        else:
            items = self.sections[row]["items"]
            position = next((index for index, item in enumerate(items) if card_key(item) == content_id),
                            min(old_position, len(items) - 1))
        self.focus_row(row)
        self.last_focus = self.row_list(row)  # Kodi's onInit after a child window refocuses this.
        self.getControl(self.row_list(row)).selectItem(position)
        item = self.sections[row]["items"][position]
        self.application.guard(lambda: self.show_hero(item))
        return True

    def update_hero(self):
        """Debounced: show the focused card in the hero; keep the last one otherwise."""
        index = self.row_of(self.focus_id())
        if index is None:
            return
        position = self.getControl(self.row_list(index)).getSelectedPosition()
        items = self.sections[index]["items"]
        if 0 <= position < len(items):
            self.application.guard(lambda: self.show_hero(items[position]))

    def show_hero(self, item):
        hero = present.hero(item, self.card_image, self.show_plot and not self.is_spoiler(item))
        set_properties(self, {
            "silo.hero.backdrop": hero["backdrop"],
            "silo.hero.logo": hero["logo"],
            "silo.hero.title": hero["title"],
            "silo.hero.meta": hero["meta"],
            "silo.hero.synopsis": hero["synopsis"],
        })
        left = HERO_LEFT
        for slot, (image_id, label_id) in enumerate(zip(BADGE_IMAGES, BADGE_LABELS)):
            text = hero["badges"][slot] if slot < len(hero["badges"]) else ""
            self.setProperty("silo.hero.badge{}".format(slot + 1), text)
            if text:
                width = present.badge_width(text)
                for control_id in (image_id, label_id):
                    self.getControl(control_id).setPosition(left, BADGE_TOP)
                    self.getControl(control_id).setWidth(width)
                left += width + BADGE_GAP
        self.getControl(HERO_META).setPosition(left, BADGE_TOP)
        # Without a synopsis the title block drops so the hero stays bottom-aligned.
        self.getControl(HERO_GROUP).setPosition(0, 0 if hero["synopsis"] else NO_SYNOPSIS_SHIFT)

    # ------------------------------------------------------------ spoilers

    def is_spoiler(self, item):
        return (self.hide_spoilers and isinstance(item, dict) and item.get("type") == "episode"
                and not svc_personal.state(item)["watched"])

    def card_image(self, item, kind):
        """Artwork for cards and the hero; unwatched episodes show series art when spoilers are hidden."""
        if kind not in ("poster", "backdrop") or not self.is_spoiler(item):
            return self.application.image(item, kind)
        # The card's own art is safe only when the server says it is not an episode still.
        for own in (kind, "backdrop" if kind == "poster" else "poster"):
            if item.get(own + "_is_episode_still") is False and item.get(own + "_url"):
                return self.application.image(item, own)
        series = self.series_art(item.get("series_id"))
        return self.application.image(series, kind) if series else ""

    def series_art(self, series_id):
        if not series_id:
            return {}
        if series_id not in self.series_art_cache:
            try:
                series = self.application.client.item(series_id)
            except Exception:  # Art is optional; a failed lookup leaves the card on its placeholder.
                series = None
            self.series_art_cache[series_id] = series if isinstance(series, dict) else {}
        return self.series_art_cache[series_id]

    # ------------------------------------------------------------ home rows editor

    def edit_home_rows(self):
        """Reorder or hide home rows with dialogs; saved per server and profile."""
        dialog = self.application.dialog
        prefs = self.row_prefs()
        hidden = set(str(value) for value in prefs.get("hidden") or ())
        default = [str(section.get("id")) for section in self.all_sections]
        order = [str(section.get("id")) for section in apply_row_prefs(self.all_sections,
                                                                       {"order": prefs.get("order")})]
        titles = {str(section.get("id")): str(section.get("title") or "Row") for section in self.all_sections}
        changed, selected = False, 0
        while order:
            labels = [titles[section_id] + (" (hidden)" if section_id in hidden else "") for section_id in order]
            choice = dialog.select("Edit home rows", labels + ["Reset to default"], preselect=selected)
            if not isinstance(choice, int) or not 0 <= choice <= len(order):
                break
            if choice == len(order):
                order, hidden, changed, selected = list(default), set(), True, 0
                continue
            section_id = order[choice]
            actions = ([("up", "Move up")] if choice > 0 else []) + (
                [("down", "Move down")] if choice + 1 < len(order) else []) + [
                ("toggle", "Show" if section_id in hidden else "Hide")]
            picked = dialog.select(titles[section_id], [label for _key, label in actions])
            selected = choice
            if not isinstance(picked, int) or not 0 <= picked < len(actions):
                continue
            action = actions[picked][0]
            if action == "toggle":
                hidden ^= {section_id}
            else:
                target = choice - 1 if action == "up" else choice + 1
                order[choice], order[target] = order[target], order[choice]
                selected = target
            changed = True
        if not changed:
            self.setFocusId(AVATAR)
            return
        # An unchanged order is not saved, so the server's order keeps applying.
        self.save_row_prefs([] if order == default else order,
                            [section_id for section_id in order if section_id in hidden])
        self.apply_sections()
        if self.tab == "home" and self.sections:
            self.focus_row(0)
        else:
            self.setFocusId(AVATAR)

    # ------------------------------------------------------------ library grid

    def show_library(self, kind, library=None):
        """The kind's grid, for one library or (None) all of them."""
        if kind != self.kind:
            self.filters = {}
        self.kind = kind
        self.set_tab("movies" if kind == "movie" else "series")
        self.library = library
        self.sort = "title"
        self.reversed = False
        self.update_chips()
        grid = self.getControl(GRID)
        grid.setPosition(GRID_LEFT, LIBRARY_GRID_TOP)
        grid.setHeight(SCREEN_HEIGHT - LIBRARY_GRID_TOP)
        grid.controlUp(self.getControl(LIBRARY_CHIP))
        self.load_grid(self.library_params())

    def sort_value(self):
        return controls.sort_term(self.sort, self.reversed)

    def library_params(self):
        params = {"type": self.kind, "sort": self.sort_value()}
        if self.library is not None:
            params["library_id"] = self.library["id"]
        groups = filter_groups(self.filters)
        if groups:
            params["groups"] = json.dumps(groups, separators=(",", ":"))
        return params

    def update_chips(self):
        name = str(self.library.get("name") or "Library") if self.library else "All"
        sort = controls.sort_chip(SORTS, self.sort, self.reversed)
        count = active_facets(self.filters)
        chips = [(LIBRARY_CHIP, "Library: " + name, True), (SORT_CHIP, "Sort: " + sort, True),
                 (FILTER_CHIP, "Filters", False)]
        if count:
            chips.append((CLEAR_CHIP, "Clear filters", False))
        chips.append((SHUFFLE_CHIP, "Shuffle", False))
        self.getControl(CLEAR_CHIP).setVisible(bool(count))
        self.setProperty("silo.filter_count", str(count) if count else "")
        left = HERO_LEFT
        for control_id, text, chevron in chips:
            width = chip_width(text, chevron)
            if control_id == FILTER_CHIP and count:
                width += BADGE_SIZE + 8
                self.getControl(FILTER_BADGE).setPosition(left + width - 20 - BADGE_SIZE, CHIP_TOP + 12)
            chip = self.getControl(control_id)
            chip.setLabel(text)
            chip.setPosition(left, CHIP_TOP)
            chip.setWidth(width)
            for chevron_id in CHEVRONS.get(control_id, ()):
                self.getControl(chevron_id).setPosition(left + width - 52, CHIP_TOP + 16)
            left += width + CHIP_GAP
        shown = [control_id for control_id, _text, _chevron in chips]
        for before, after in zip(shown, shown[1:]):
            self.getControl(before).controlRight(self.getControl(after))
            self.getControl(after).controlLeft(self.getControl(before))

    def choose_library(self):
        libraries = self.libraries.get(self.kind) or []
        names = ["All libraries"] + [str(library.get("name") or "Library") for library in libraries]
        current = libraries.index(self.library) + 1 if self.library in libraries else 0
        choice = self.application.dialog.select("Library", names, preselect=current)
        if choice < 0 or choice == current:
            return
        self.library = libraries[choice - 1] if choice else None
        self.update_chips()
        self.load_grid(self.library_params())

    def choose_sort(self):
        """Pick a sort, or the last row to flip the current one's direction."""
        chosen = controls.choose_sort(self.application.dialog, SORTS, self.sort, self.reversed)
        if chosen is None:
            return
        self.sort, self.reversed = chosen
        self.update_chips()
        self.load_grid(self.library_params())

    def shuffle(self):
        from .svc_shuffle import play_shuffle

        library_id = self.library["id"] if self.library is not None else None
        kind = self.kind
        self.run_modal(lambda: play_shuffle(self.application, type=kind, library_id=library_id), SHUFFLE_CHIP)

    # ------------------------------------------------------------ filters

    def scope_params(self):
        params = {"type": self.kind}
        if self.library is not None:
            params["library_id"] = self.library["id"]
        return params

    def filter_options(self):
        """GET /catalog/filters for the current kind and library, cached for the window."""
        key = (self.kind, self.library["id"] if self.library is not None else None)
        if key not in self.filter_options_cache:
            response = self.application.client.request("GET", "/catalog/filters", params=self.scope_params())
            self.filter_options_cache[key] = response if isinstance(response, dict) else {}
        return self.filter_options_cache[key]

    def choose_filters(self):
        if controls.choose_filters(self.application.dialog, self.filters, self.filter_options(), self.search_facet):
            self.reload_filtered()

    def search_facet(self, facet, text, current):
        return controls.facet_search(self.application.client, self.scope_params(), facet, text, current)

    def clear_filters(self):
        if not self.filters:
            return
        self.filters = {}
        self.reload_filtered()
        self.setFocusId(FILTER_CHIP)

    def reload_filtered(self):
        self.update_chips()
        self.load_grid(self.library_params())

    # ------------------------------------------------------------ grid loading

    def clear_grid(self, empty=""):
        self.generation += 1
        self.params, self.grid_items, self.cursor = None, [], None
        self.getControl(GRID).reset()
        self.setProperty("silo.total", "")
        self.setProperty("silo.empty", empty)

    def load_grid(self, params, seek=None, lead=()):
        """Load the first page; ``seek`` starts it at a list position (the A–Z rail), and
        ``lead`` (search's box sets) comes ahead of it so the grid never shifts under focus."""
        self.clear_grid()
        generation = self.generation
        self.params = params
        query = dict(params, seek=seek) if seek else dict(params)
        response = self.application.guard(lambda: self.application.browse(query))
        if generation != self.generation:
            return
        if response is None:
            self.setProperty("silo.empty", "Titles could not be loaded.")
            return
        self.append_page(response, lead)
        if seek is None:
            self.load_letters()

    def append_page(self, response, lead=()):
        items = [dict(found, type=BOX_SET) for found in lead] + present.video_items(response.get("items"))
        self.grid_items.extend(items)
        self.getControl(GRID).addItems([box_set_list_item(item, self.application.image) if item["type"] == BOX_SET
                                        else card_list_item(item, self.card_image) for item in items])
        self.cursor = response.get("next_cursor") or None
        if self.tab in TAB_KINDS:
            self.setProperty("silo.total", total_text(response.get("total")))
        if not self.grid_items:
            self.setProperty("silo.empty", "No results" if self.tab == "search" else "No titles to show")
        else:
            self.setProperty("silo.empty", "")

    def load_more(self):
        """Fetch the next page when the selection nears the end of the grid."""
        if not self.cursor or self.params is None:
            return
        if self.getControl(GRID).getSelectedPosition() < len(self.grid_items) - LOAD_AHEAD:
            return
        generation, cursor = self.generation, self.cursor
        self.cursor = None  # One request at a time; a failed page is not retried on every key press.
        response = self.application.browse(dict(self.params), cursor)
        if generation == self.generation and response is not None:
            self.append_page(response)

    # ------------------------------------------------------------ A–Z rail

    def rail_active(self):
        return self.tab in TAB_KINDS and self.sort == "title" and not self.reversed

    def update_rail(self):
        active = self.rail_active()
        self.setProperty("silo.rail", "true" if active else "")
        self.getControl(RAIL_GROUP).setVisible(active)
        if not active:
            self.letters = None

    def fill_rail(self):
        rail = self.getControl(RAIL)
        rail.reset()
        items = []
        for letter in RAIL_LETTERS:
            item = xbmcgui.ListItem(label=letter)
            item.setProperty("silo.has", "true")
            items.append(item)
        rail.addItems(items)

    def load_letters(self):
        """POST /catalog/letters for the grid's scope and filters; letters without titles are dimmed."""
        self.update_rail()
        if not self.rail_active() or self.params is None:
            return
        body = {"type": self.kind, "order": "asc"}
        if self.library is not None:
            body["library_id"] = str(self.library["id"])
        groups = filter_groups(self.filters)
        if groups:
            body["groups"] = groups
        try:
            response = self.application.client.request("POST", "/catalog/letters", body=body)
        except Exception:  # Without the index the rail still offers All and every letter.
            response = None
        letters = {}
        entries = response.get("letters") if isinstance(response, dict) else None
        for entry in entries or ():
            if isinstance(entry, dict) and isinstance(entry.get("position"), int):
                letters[str(entry.get("letter"))] = entry["position"]
        self.letters = letters if isinstance(response, dict) else None
        rail = self.getControl(RAIL)
        for index, letter in enumerate(RAIL_LETTERS):
            has = letter == "All" or self.letters is None or letter in self.letters
            try:
                rail.getListItem(index).setProperty("silo.has", "true" if has else "")
            except (RuntimeError, AttributeError):
                pass

    def jump_to_letter(self):
        """Load the grid from the chosen letter's first title and focus it."""
        position = self.getControl(RAIL).getSelectedPosition()
        if not 0 <= position < len(RAIL_LETTERS) or self.params is None:
            return
        letter = RAIL_LETTERS[position]
        if letter == "All":
            seek = 0
        elif self.letters is None or letter not in self.letters:
            return
        else:
            seek = self.letters[letter]
        params, letters = self.params, self.letters
        self.load_grid(params, seek=seek)
        self.letters = letters
        if self.grid_items:
            self.setFocusId(GRID)
            self.getControl(GRID).selectItem(0)

    # ------------------------------------------------------------ search

    def show_search(self):
        self.set_tab("search")
        grid = self.getControl(GRID)
        grid.setPosition(GRID_LEFT, SEARCH_GRID_TOP)
        grid.setHeight(SCREEN_HEIGHT - SEARCH_GRID_TOP)
        self.select_search_type(self.search_type)
        self.setFocusId(SEARCH_FIELD)

    def select_search_type(self, search_type):
        self.search_type = search_type
        self.setProperty("silo.search_type", search_type)
        self.run_search()

    def edit_query(self):
        text = (self.application.dialog.input(search_heading("Search"), self.query) or "").strip()
        if not text:
            return
        self.query = text
        self.setProperty("silo.query", text)
        self.run_search()

    def run_search(self):
        if not self.query:
            self.show_people([])
            self.clear_grid("Search your library")
            return
        self.show_people(self.search_people())
        self.load_grid({"q": self.query, "type": self.search_type}, lead=self.search_box_sets())

    def search_box_sets(self):
        """GET /catalog/box-sets, asked only while some library has box sets on; optional, like People."""
        if self.search_type not in BOX_SET_SEARCH_TYPES:
            return []
        try:
            if not self.application.box_sets_on():
                return []
            return svc_boxsets.search(self.application.client, self.query)
        except Exception:
            return []

    def search_people(self):
        """GET /catalog/people; the row is optional, so a failure just hides it."""
        params = {"q": self.query, "limit": PEOPLE_LIMIT, "media_scope": self.search_type}
        try:
            response = self.application.client.request("GET", "/catalog/people", params=params)
        except Exception:
            return []
        items = response.get("items") if isinstance(response, dict) else None
        return [person for person in items or () if isinstance(person, dict) and person.get("id") is not None]

    def show_people(self, people):
        """Fill the People row and move the grid below it."""
        self.people = people
        control = self.getControl(PEOPLE_LIST)
        control.reset()
        if people:
            control.addItems([self.person_item(person) for person in people])
        self.setProperty("silo.people", "true" if people else "")
        self.getControl(PEOPLE_GROUP).setVisible(bool(people))
        if self.tab != "search":
            return
        grid = self.getControl(GRID)
        chip = self.getControl(next(control_id for control_id, value in SEARCH_CHIPS.items()
                                    if value == self.search_type))
        top = SEARCH_GRID_TOP + (PEOPLE_HEIGHT if people else 0)
        grid.setPosition(GRID_LEFT, top)
        grid.setHeight(SCREEN_HEIGHT - top)
        below = control if people else grid
        for chip_id in SEARCH_CHIPS:
            self.getControl(chip_id).controlDown(below)
        if people:
            control.controlUp(chip)
            control.controlDown(grid)
        grid.controlUp(below if people else chip)

    def person_item(self, person):
        name = str(person.get("name") or "")
        item = xbmcgui.ListItem(label=name)
        # application.image validates the presigned URL like any other artwork URL.
        photo = self.application.image({"poster_url": person["photo_url"]}, "poster") if person.get(
            "photo_url") else ""
        if photo:
            item.setArt({"thumb": photo})
        item.setProperty("silo.initials", present.initials(name))
        return item

    def open_person(self):
        position = self.getControl(PEOPLE_LIST).getSelectedPosition()
        if not 0 <= position < len(self.people):
            return
        person = self.people[position]
        self.run_modal(lambda: self.application.open_screen(
            "person", person_id=person["id"], name=str(person.get("name") or "")), PEOPLE_LIST)

    # ------------------------------------------------------------ card context menu

    def context_card(self, control_id):
        """(item, row or None) for the selected card of a home row or the grid."""
        row = self.row_of(control_id)
        if row is not None:
            items = self.sections[row]["items"]
        elif control_id == GRID:
            items = self.grid_items
        else:
            return None, None
        position = self.getControl(control_id).getSelectedPosition()
        if not 0 <= position < len(items):
            return None, None
        return items[position], row

    def card_menu(self, control_id):
        item, row = self.context_card(control_id)
        if item is None or item.get("type") in (BOX_SET, COLLECTION):  # These cards have no item menu.
            return
        before, after = [], []
        if row is not None and self.sections[row].get("section_type") == "continue_watching":
            # Android's Continue Watching menu starts with Play, or Resume where the card has progress.
            before.append(("play", "Resume" if resume_position(item) > 0 else "Play"))
        surface = svc_personal.dismiss_surface(item) if row is not None and self.is_wide(row) else None
        if surface:
            after.append(("dismiss", "Remove from Continue Watching" if surface == "continue_watching"
                          else "Remove from Next Up"))
        if item.get("type") == "episode" and item.get("series_id"):
            after.append(("series", "Go to series"))
        action = card_menu(self.application, item, before=before, after=after)
        if action is None:
            return
        if action == "play":
            self.run_modal(lambda: self.application.play_card(item), control_id)
            return
        if action == "series":
            card = {"content_id": item["series_id"], "type": "series"}
            self.run_modal(lambda: self.application.open_item(card), control_id)
            return
        if action == "dismiss" and self.application.guard(lambda: self.dismiss(surface, item) or True) is None:
            return
        if row is not None:
            self.refresh_after(control_id, self.card_at(control_id))
        else:
            update_card(self.getControl(control_id), self.getControl(control_id).getSelectedPosition(), item,
                        self.card_image)

    def dismiss(self, surface, item):
        """PUT /home/dismissals/{surface}/{id} with the anchor the server requires for the surface."""
        if surface not in svc_personal.DISMISS_SURFACES:
            raise ValueError("Unknown home surface: {}".format(surface))
        if surface == "next_up":
            anchor = {"series_id": item.get("series_id") or (
                item["content_id"] if item.get("type") == "series" else None)}
        else:
            anchor = {"progress_updated_at": item.get("progress_updated_at")}
        path = "/home/dismissals/{}/{}".format(surface, quote(str(item["content_id"]), safe=""))
        return self.application.client.request(
            "PUT", path, body={key: value for key, value in anchor.items() if value})

    # ------------------------------------------------------------ modal screens and refresh

    def run_modal(self, callback, focus):
        """Run a modal screen, then refresh home rows and return focus where it was."""
        card = self.card_at(focus) if self.tab == "home" else None
        self.last_focus = focus
        try:
            callback()
        finally:
            self.refresh_after(focus, card)

    def refresh_after(self, focus, card=None):
        if self.tab == "home":
            if self.refresh_home(card):
                return
        else:
            self.home_stale = True  # Home reloads when it is shown again.
        self.setFocusId(focus)

    # ------------------------------------------------------------ input

    def onFocus(self, control_id):
        if self.row_of(control_id) is not None:
            self.hero_debouncer.trigger()
        elif control_id in LIBRARY_TABS:
            self.prepare_panel(LIBRARY_TABS[control_id])
        elif control_id == LIB_LIST:
            self.follow_library_row()
        elif control_id == TAB_BUTTONS["for_you"]:
            self.place_for_you()
        elif control_id in (LIB_EXIT, FOR_YOU_EXIT):
            # Down past a panel's last row continues into the page.
            self.left_panel = True
            self.focus_content()

    def onAction(self, action):
        action_id = action.getId()
        if action_id in BACK_ACTIONS:
            self.back()
            return
        if self.menu_open:
            if action_id in (ACTION_LEFT, ACTION_RIGHT):
                self.close_menu()
            return
        focus = self.focus_id()
        if self.left_panel:
            self.left_panel = False
            if action_id == ACTION_DOWN:
                return
        if focus == LIB_LIST and action_id in (ACTION_UP, ACTION_DOWN, ACTION_MOUSE_MOVE):
            # Kodi has already moved the selection: the flyout follows the focused library.
            self.follow_library_row()
            return
        if focus in PANEL_CONTROLS:
            return
        row = self.row_of(focus)
        if action_id in CONTEXT_ACTIONS:
            if row is not None or focus == GRID:
                self.application.guard(lambda: self.card_menu(focus))
            return
        if action_id == ACTION_UP:
            if row is not None:
                if row > 0:
                    self.focus_row(row - 1)
                else:
                    self.focus_tab()
            elif focus in CHIPS or focus == SEARCH_FIELD:
                self.focus_tab()
        elif action_id == ACTION_DOWN:
            if row is not None:
                if row + 1 < len(self.sections):
                    self.focus_row(row + 1)
            elif focus in LIBRARY_TABS:
                self.enter_panel(LIBRARY_TABS[focus])
            elif focus == TAB_BUTTONS["for_you"]:
                self.setFocusId(min(FOR_YOU_ITEMS))
            elif focus in BAR_CONTROLS:
                self.focus_content()
        elif action_id in (ACTION_LEFT, ACTION_RIGHT) and row is not None:
            self.hero_debouncer.trigger()
        if focus == GRID and action_id in (ACTION_UP, ACTION_DOWN, ACTION_LEFT, ACTION_RIGHT):
            self.application.guard(self.load_more)

    def back(self):
        focus = self.focus_id()
        if self.menu_open:
            self.close_menu()
        elif focus in PANEL_CONTROLS:
            self.setFocusId(self.panel_tab(focus))
        elif self.tab != "home":
            self.show_home()
        elif self.row_of(self.focus_id()) is not None:
            # Back from the rows comes up to the Home tab first.
            self.focus_tab()
        elif self.application.options().get("confirm_exit", True):
            self.confirm_exit()
        else:
            self.result = None
            self.close()

    def confirm_exit(self):
        """Ask before leaving; focus starts on Cancel, and Back in the dialog also stays.
        Hide Quit Kodi drops that button for systems where Kodi is the whole device (OSMC)."""
        heading, message = "Exit Founders Theater", "Are you ready to exit Founders Theater?"
        cancel = getattr(xbmcgui, "DLG_YESNO_NO_BTN", 10)
        if self.application.options().get("hide_quit_kodi"):
            answer = 1 if self.application.dialog.yesno(heading, message, nolabel="Cancel", yeslabel="Exit",
                                                        defaultbutton=cancel) else 0
        else:
            answer = self.application.dialog.yesnocustom(heading, message, customlabel="Quit Kodi", nolabel="Cancel",
                                                         yeslabel="Exit", defaultbutton=cancel)
        if answer in (1, 2):
            self.result = "quit_kodi" if answer == 2 else None
            self.close()

    def onClick(self, control_id):
        self.application.guard(lambda: self._click(control_id))

    def _click(self, control_id):
        row = self.row_of(control_id)
        if row is not None:
            self.open(self.sections[row]["items"], control_id)
        elif control_id == GRID:
            self.open(self.grid_items, control_id)
        elif control_id in MENU_ITEMS:
            self.choose_menu(control_id)
        elif control_id == LIB_LIST:
            self.open_flyout()
        elif control_id == FLYOUT_LIST:
            self.choose_section()
        elif control_id in FOR_YOU_ITEMS:
            self.choose_for_you(control_id)
        elif control_id == AVATAR:
            self.open_menu()
        elif control_id == TABS[0][1]:
            self.select_home_tab()
        elif control_id in LIBRARY_TABS:
            self.show_library(LIBRARY_TABS[control_id])
        elif control_id in SCREEN_TABS:
            self.open_screen_tab(control_id)
        elif control_id == SEARCH_BUTTON:
            self.show_search()
        elif control_id == LIBRARY_CHIP:
            self.choose_library()
        elif control_id == SORT_CHIP:
            self.choose_sort()
        elif control_id == FILTER_CHIP:
            self.choose_filters()
        elif control_id == CLEAR_CHIP:
            self.clear_filters()
        elif control_id == SHUFFLE_CHIP:
            self.shuffle()
        elif control_id == RAIL:
            self.jump_to_letter()
        elif control_id == PEOPLE_LIST:
            self.open_person()
        elif control_id == SEARCH_FIELD:
            self.edit_query()
        elif control_id in SEARCH_CHIPS and SEARCH_CHIPS[control_id] != self.search_type:
            self.select_search_type(SEARCH_CHIPS[control_id])

    def open(self, items, control_id):
        position = self.getControl(control_id).getSelectedPosition()
        if not 0 <= position < len(items):
            return
        item = items[position]
        if item.get("type") == BOX_SET:
            self.run_modal(lambda: self.application.open_screen(
                "box_set", box_set_id=item["id"], library_id=item["library_id"]), control_id)
            return
        if item.get("type") == COLLECTION:
            self.run_modal(lambda: self.application.open_screen("collection", collection=item), control_id)
            return
        self.run_modal(lambda: self.application.open_item(item), control_id)
