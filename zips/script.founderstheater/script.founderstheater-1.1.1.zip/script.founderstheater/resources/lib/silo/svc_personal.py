"""The profile's own lists and marks: watchlist, favorites, watched, ratings, history.

Routes are Silo /api/v2: PUT/DELETE /watchlist/{id}, PUT/DELETE /favorites/{id},
POST/DELETE /watched/{id} (a season or series expands to its episodes),
PUT/DELETE /ratings/{id} (1 to 10, two per star; item detail carries it as user_rating),
PUT /home/dismissals/{surface}/{id}, and GET /watchlist, /favorites, /history.
"""

from urllib.parse import quote

DISMISS_SURFACES = ("continue_watching", "next_up")


def _id(item_id):
    return quote(str(item_id), safe="")


def set_watchlist(client, item_id, on):
    return client.request("PUT" if on else "DELETE", "/watchlist/" + _id(item_id))


def set_favorite(client, item_id, on):
    return client.request("PUT" if on else "DELETE", "/favorites/" + _id(item_id))


def set_watched(client, item_id, on):
    return client.request("POST" if on else "DELETE", "/watched/" + _id(item_id))


# A card menu's marks in the order every Founders Theater menu lists them, the flag each one
# keeps in a card's user_state (and user_data), its setter, and its labels when off and on.
MARK_KINDS = ("watched", "watchlist", "favorite")
_MARKS = {
    "watched": ("played", set_watched, ("Mark as watched", "Mark as unwatched")),
    "watchlist": ("in_watchlist", set_watchlist, ("Add to watchlist", "Remove from watchlist")),
    "favorite": ("is_favorite", set_favorite, ("Add to favorites", "Remove from favorites")),
}


def mark_entries(item, kinds=MARK_KINDS):
    """A card menu's mark entries as (kind, label), each naming what choosing it does."""
    marks = state(item)
    return [(kind, _MARKS[kind][2][marks[kind]]) for kind in kinds]


def set_mark(item, kind, on):
    """Record a mark on the card itself (user_state, and user_data when the card has it)."""
    field = _MARKS[kind][0]
    user_state = item.get("user_state") if isinstance(item.get("user_state"), dict) else {}
    item["user_state"] = dict(user_state, **{field: on})
    if isinstance(item.get("user_data"), dict):
        item["user_data"] = dict(item["user_data"], **{field: on})


def toggle_mark(client, item, kind):
    """Flip one mark on the server, then on ``item``; returns the new value."""
    on = not state(item)[kind]
    _MARKS[kind][1](client, item["content_id"], on)
    set_mark(item, kind, on)
    return on


def rating(item):
    """The profile's rating for an item detail (1 to 10, two per star), or None when unrated."""
    value = (item or {}).get("user_rating")
    return value if isinstance(value, int) and not isinstance(value, bool) and 1 <= value <= 10 else None


def set_rating(client, item_id, score):
    """Rate an item 1 to 10 (two per star, so 8 is 4 stars); None removes the rating."""
    if score is None:
        return client.request("DELETE", "/ratings/" + _id(item_id))
    if not isinstance(score, int) or isinstance(score, bool) or not 1 <= score <= 10:
        raise ValueError("A rating is 1 to 10.")
    return client.request("PUT", "/ratings/" + _id(item_id), body={"rating": score})


def dismiss(client, surface, item_id, item=None):
    """Hide a card from Continue Watching or Next Up on every device.

    The server anchors a dismissal: Next Up needs the card's series_id, and
    Continue Watching its progress_updated_at (the card returns once the title
    is played again). Both come from the home card ``item``.
    """
    if surface not in DISMISS_SURFACES:
        raise ValueError("Unknown home surface: {}".format(surface))
    item = item or {}
    if surface == "next_up":
        body = {"series_id": item.get("series_id")}
    else:
        body = {"progress_updated_at": item.get("progress_updated_at")}
    if not all(body.values()):
        raise ValueError("This card cannot be removed from {}.".format(surface.replace("_", " ")))
    return client.request("PUT", "/home/dismissals/{}/{}".format(surface, _id(item_id)), body)


def dismiss_surface(item):
    """The surface a home card belongs to, from the card's item_source."""
    return {"in_progress": "continue_watching", "next_up": "next_up"}.get(item.get("item_source"))


def _page(client, path, cursor=None, limit=50, **params):
    params = dict(params, limit=limit)
    if cursor:
        params["cursor"] = cursor
    response = client.request("GET", path, params=params) or {}
    page = response.get("page") or {}
    return {"items": [item for item in response.get("items", []) if isinstance(item, dict)],
            "next_cursor": page.get("next_cursor") if page.get("has_more") else None,
            "total": response.get("total")}


def watchlist(client, cursor=None, limit=50):
    return _page(client, "/watchlist", cursor, limit)


def favorites(client, cursor=None, limit=50):
    return _page(client, "/favorites", cursor, limit)


def history(client, cursor=None, limit=50):
    return _page(client, "/history", cursor, limit)


def state(item):
    """The card's current marks, from user_state (catalog) or user_data (details)."""
    marks = {}
    for key in ("user_state", "user_data"):
        if isinstance(item.get(key), dict):
            marks.update(item[key])
    return {"watchlist": marks.get("in_watchlist") is True, "favorite": marks.get("is_favorite") is True,
            "watched": marks.get("played") is True}
